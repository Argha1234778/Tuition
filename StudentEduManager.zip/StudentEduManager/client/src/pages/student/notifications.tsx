import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ScrollArea } from "@/components/ui/scroll-area";
import { 
  Bell, 
  Settings,
  Check,
  CheckCheck,
  Filter,
  Calendar,
  Clock,
  AlertCircle,
  Info,
  CheckCircle,
  AlertTriangle
} from "lucide-react";
import StudentLayout from "@/components/student-layout";
import NotificationPreferences from "@/components/notification-preferences";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { formatDistanceToNow } from "date-fns";

interface Notification {
  id: number;
  title: string;
  message: string;
  type: 'info' | 'success' | 'warning' | 'error' | 'reminder';
  category: 'payment' | 'attendance' | 'course' | 'grade' | 'system' | 'announcement';
  priority: 'low' | 'medium' | 'high' | 'urgent';
  isRead: boolean;
  actionUrl?: string;
  actionLabel?: string;
  createdAt: string;
  readAt?: string;
}

export default function StudentNotifications() {
  const [isPreferencesOpen, setIsPreferencesOpen] = useState(false);
  const [filter, setFilter] = useState<string>('all');

  // Mock notifications for demonstration
  const notifications: Notification[] = [
    {
      id: 1,
      title: "Payment Due Reminder",
      message: "Your monthly tuition payment of $500 is due in 3 days. Please make payment to avoid late fees.",
      type: 'warning',
      category: 'payment',
      priority: 'high',
      isRead: false,
      actionUrl: '/student/payments',
      actionLabel: 'Make Payment',
      createdAt: new Date(Date.now() - 2 * 60 * 60 * 1000).toISOString(),
    },
    {
      id: 2,
      title: "New Grade Posted",
      message: "Your grade for 'Database Design' assignment has been posted. You received an A- grade.",
      type: 'success',
      category: 'grade',
      priority: 'medium',
      isRead: false,
      actionUrl: '/student/progress',
      actionLabel: 'View Grade',
      createdAt: new Date(Date.now() - 5 * 60 * 60 * 1000).toISOString(),
    },
    {
      id: 3,
      title: "Attendance Alert",
      message: "You were marked absent for today's Computer Science class. Please contact your instructor if this is incorrect.",
      type: 'error',
      category: 'attendance',
      priority: 'high',
      isRead: true,
      readAt: new Date(Date.now() - 1 * 60 * 60 * 1000).toISOString(),
      createdAt: new Date(Date.now() - 8 * 60 * 60 * 1000).toISOString(),
    },
    {
      id: 4,
      title: "Course Material Updated",
      message: "New study materials have been uploaded for 'Advanced Programming'. Check the materials section for the latest resources.",
      type: 'info',
      category: 'course',
      priority: 'medium',
      isRead: true,
      readAt: new Date(Date.now() - 2 * 60 * 60 * 1000).toISOString(),
      actionUrl: '/student/courses',
      actionLabel: 'View Materials',
      createdAt: new Date(Date.now() - 12 * 60 * 60 * 1000).toISOString(),
    },
    {
      id: 5,
      title: "Weekly Progress Report",
      message: "Your weekly progress report is ready. You've completed 8 out of 10 assignments this week.",
      type: 'info',
      category: 'grade',
      priority: 'low',
      isRead: false,
      actionUrl: '/student/progress',
      actionLabel: 'View Report',
      createdAt: new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString(),
    },
    {
      id: 6,
      title: "System Maintenance Notice",
      message: "Scheduled system maintenance will occur this weekend from 2-4 AM. Some features may be temporarily unavailable.",
      type: 'info',
      category: 'system',
      priority: 'low',
      isRead: false,
      createdAt: new Date(Date.now() - 48 * 60 * 60 * 1000).toISOString(),
    }
  ];

  const filteredNotifications = notifications.filter(notification => {
    if (filter === 'unread') return !notification.isRead;
    if (filter === 'urgent') return notification.priority === 'urgent' || notification.priority === 'high';
    if (filter !== 'all') return notification.category === filter;
    return true;
  });

  const unreadCount = notifications.filter(n => !n.isRead).length;
  const urgentCount = notifications.filter(n => 
    (n.priority === 'urgent' || n.priority === 'high') && !n.isRead
  ).length;

  const getNotificationIcon = (type: string) => {
    switch (type) {
      case 'success':
        return <CheckCircle className="h-5 w-5 text-green-600" />;
      case 'warning':
        return <AlertTriangle className="h-5 w-5 text-yellow-600" />;
      case 'error':
        return <AlertCircle className="h-5 w-5 text-red-600" />;
      case 'reminder':
        return <Clock className="h-5 w-5 text-blue-600" />;
      default:
        return <Info className="h-5 w-5 text-blue-600" />;
    }
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'urgent':
        return 'bg-red-100 text-red-800 border-red-200';
      case 'high':
        return 'bg-orange-100 text-orange-800 border-orange-200';
      case 'medium':
        return 'bg-blue-100 text-blue-800 border-blue-200';
      default:
        return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  const getCategoryColor = (category: string) => {
    switch (category) {
      case 'payment':
        return 'bg-yellow-100 text-yellow-800';
      case 'attendance':
        return 'bg-red-100 text-red-800';
      case 'course':
        return 'bg-blue-100 text-blue-800';
      case 'grade':
        return 'bg-green-100 text-green-800';
      case 'system':
        return 'bg-purple-100 text-purple-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <StudentLayout 
      title="Notifications" 
      description="Stay updated with important alerts and announcements"
    >
      <div className="space-y-6">
        {/* Summary Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Total Notifications</p>
                  <p className="text-2xl font-bold">{notifications.length}</p>
                </div>
                <Bell className="h-8 w-8 text-blue-600" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Unread</p>
                  <p className="text-2xl font-bold text-orange-600">{unreadCount}</p>
                </div>
                <div className="w-8 h-8 bg-orange-100 rounded-lg flex items-center justify-center">
                  <Bell className="h-5 w-5 text-orange-600" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Urgent</p>
                  <p className="text-2xl font-bold text-red-600">{urgentCount}</p>
                </div>
                <div className="w-8 h-8 bg-red-100 rounded-lg flex items-center justify-center">
                  <AlertCircle className="h-5 w-5 text-red-600" />
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Quick Actions */}
        <div className="flex flex-wrap gap-4 items-center justify-between">
          <div className="flex flex-wrap gap-2">
            <Button 
              variant={filter === 'all' ? 'default' : 'outline'} 
              size="sm"
              onClick={() => setFilter('all')}
            >
              All
            </Button>
            <Button 
              variant={filter === 'unread' ? 'default' : 'outline'} 
              size="sm"
              onClick={() => setFilter('unread')}
            >
              Unread
            </Button>
            <Button 
              variant={filter === 'urgent' ? 'default' : 'outline'} 
              size="sm"
              onClick={() => setFilter('urgent')}
            >
              Urgent
            </Button>
            <Button 
              variant={filter === 'payment' ? 'default' : 'outline'} 
              size="sm"
              onClick={() => setFilter('payment')}
            >
              Payments
            </Button>
            <Button 
              variant={filter === 'grade' ? 'default' : 'outline'} 
              size="sm"
              onClick={() => setFilter('grade')}
            >
              Grades
            </Button>
          </div>
          
          <Button variant="outline" onClick={() => setIsPreferencesOpen(true)}>
            <Settings className="h-4 w-4 mr-2" />
            Preferences
          </Button>
        </div>

        {/* Notifications List */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center justify-between">
              <span>Notifications</span>
              <Badge variant="outline">{filteredNotifications.length} notifications</Badge>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ScrollArea className="h-96">
              {filteredNotifications.length === 0 ? (
                <div className="text-center py-8">
                  <Bell className="h-12 w-12 text-muted-foreground mx-auto mb-4 opacity-50" />
                  <h4 className="text-lg font-medium text-muted-foreground mb-2">No notifications</h4>
                  <p className="text-sm text-muted-foreground">
                    {filter === 'all' 
                      ? "You don't have any notifications yet"
                      : `No ${filter} notifications found`
                    }
                  </p>
                </div>
              ) : (
                <div className="space-y-4">
                  {filteredNotifications.map((notification) => (
                    <div
                      key={notification.id}
                      className={`p-4 border rounded-lg hover:bg-accent/50 transition-colors cursor-pointer ${
                        !notification.isRead ? 'bg-blue-50/50 border-blue-200' : 'border-border'
                      }`}
                    >
                      <div className="flex items-start space-x-3">
                        <div className="flex-shrink-0 mt-1">
                          {getNotificationIcon(notification.type)}
                        </div>
                        
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center justify-between mb-2">
                            <h4 className={`font-medium ${!notification.isRead ? 'font-semibold' : ''}`}>
                              {notification.title}
                            </h4>
                            <div className="flex items-center space-x-2">
                              <Badge
                                variant="outline"
                                className={`text-xs ${getPriorityColor(notification.priority)}`}
                              >
                                {notification.priority}
                              </Badge>
                              <Badge
                                variant="outline"
                                className={`text-xs ${getCategoryColor(notification.category)}`}
                              >
                                {notification.category}
                              </Badge>
                              {!notification.isRead && (
                                <div className="w-2 h-2 bg-blue-600 rounded-full"></div>
                              )}
                            </div>
                          </div>
                          
                          <p className="text-sm text-muted-foreground mb-3 leading-relaxed">
                            {notification.message}
                          </p>
                          
                          <div className="flex items-center justify-between">
                            <div className="flex items-center space-x-4 text-xs text-muted-foreground">
                              <div className="flex items-center space-x-1">
                                <Calendar className="h-3 w-3" />
                                <span>
                                  {formatDistanceToNow(new Date(notification.createdAt), { addSuffix: true })}
                                </span>
                              </div>
                              {notification.readAt && (
                                <div className="flex items-center space-x-1">
                                  <Check className="h-3 w-3" />
                                  <span>
                                    Read {formatDistanceToNow(new Date(notification.readAt), { addSuffix: true })}
                                  </span>
                                </div>
                              )}
                            </div>
                            
                            {notification.actionLabel && notification.actionUrl && (
                              <Button
                                variant="outline"
                                size="sm"
                                className="text-xs"
                              >
                                {notification.actionLabel}
                              </Button>
                            )}
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </ScrollArea>
          </CardContent>
        </Card>
      </div>

      {/* Notification Preferences Modal */}
      <Dialog open={isPreferencesOpen} onOpenChange={setIsPreferencesOpen}>
        <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Notification Preferences</DialogTitle>
          </DialogHeader>
          <NotificationPreferences onClose={() => setIsPreferencesOpen(false)} />
        </DialogContent>
      </Dialog>
    </StudentLayout>
  );
}