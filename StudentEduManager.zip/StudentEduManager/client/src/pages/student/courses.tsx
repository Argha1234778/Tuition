import { useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { BookOpen, Calculator, Atom, FlaskConical, Star } from "lucide-react";
import StudentLayout from "@/components/student-layout";
import StudyMaterials from "@/components/study-materials";
import { AuthService } from "@/lib/auth";
import type { EnrollmentWithDetails } from "@shared/schema";

const getCourseIcon = (courseName: string) => {
  const name = courseName.toLowerCase();
  if (name.includes('math')) return Calculator;
  if (name.includes('physics')) return Atom;
  if (name.includes('chemistry')) return FlaskConical;
  return BookOpen;
};

const getGradeColor = (grade: string) => {
  if (grade.startsWith('A')) return 'text-green-600';
  if (grade.startsWith('B')) return 'text-blue-600';
  if (grade.startsWith('C')) return 'text-yellow-600';
  return 'text-gray-600';
};

export default function StudentCourses() {
  const { data: auth } = useQuery({
    queryKey: ['/api/auth/me'],
    queryFn: () => AuthService.getCurrentUser(),
  });

  const studentId = auth?.student?.id;

  const { data: enrollments = [], isLoading } = useQuery<EnrollmentWithDetails[]>({
    queryKey: ['/api/enrollments', studentId],
    enabled: !!studentId,
  });

  const activeEnrollments = enrollments.filter(e => e.status === 'active');

  if (isLoading) {
    return (
      <StudentLayout title="My Courses" description="Loading your courses...">
        <div className="flex items-center justify-center h-64">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
        </div>
      </StudentLayout>
    );
  }

  return (
    <StudentLayout title="My Courses" description="Track your enrolled courses and progress">
      <div className="space-y-6">
        {activeEnrollments.length === 0 ? (
          <Card>
            <CardContent className="text-center py-8">
              <BookOpen className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
              <p className="text-muted-foreground">You are not enrolled in any courses yet</p>
            </CardContent>
          </Card>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {activeEnrollments.map((enrollment) => {
              const Icon = getCourseIcon(enrollment.course.name);
              const progress = enrollment.progress || 0;
              const grade = enrollment.grade || 'N/A';
              
              return (
                <Card key={enrollment.id} className="card-hover">
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between mb-4">
                      <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center">
                        <Icon className="h-6 w-6 text-primary" />
                      </div>
                      <Badge className="bg-green-100 text-green-800">
                        {enrollment.status.charAt(0).toUpperCase() + enrollment.status.slice(1)}
                      </Badge>
                    </div>
                    
                    <h3 className="text-lg font-semibold mb-2">{enrollment.course.name}</h3>
                    <p className="text-muted-foreground text-sm mb-4 line-clamp-2">
                      {enrollment.course.description || "No description available"}
                    </p>
                    
                    {/* Progress Bar */}
                    <div className="mb-4">
                      <div className="flex justify-between text-sm mb-2">
                        <span className="text-muted-foreground">Progress</span>
                        <span className="font-medium">{progress}%</span>
                      </div>
                      <Progress value={progress} className="h-2" />
                    </div>

                    <div className="space-y-2 text-sm">
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Grade:</span>
                        <span className={`font-medium ${getGradeColor(grade)}`}>
                          {grade}
                        </span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Duration:</span>
                        <span className="font-medium">{enrollment.course.duration} weeks</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Enrolled:</span>
                        <span className="font-medium">
                          {new Date(enrollment.enrollmentDate).toLocaleDateString()}
                        </span>
                      </div>
                    </div>
                    
                    <div className="mt-4 pt-4 border-t border-border">
                      <StudyMaterials courseId={enrollment.course.id} />
                    </div>

                    {/* Course Status Indicator */}
                    <div className="mt-4 p-3 bg-muted rounded-lg">
                      <div className="flex items-center justify-between">
                        <span className="text-sm text-muted-foreground">Course Status</span>
                        <div className="flex items-center space-x-2">
                          {progress === 100 ? (
                            <Badge className="bg-green-100 text-green-800">
                              Completed
                            </Badge>
                          ) : progress > 0 ? (
                            <Badge className="bg-blue-100 text-blue-800">
                              In Progress
                            </Badge>
                          ) : (
                            <Badge className="bg-gray-100 text-gray-800">
                              Not Started
                            </Badge>
                          )}
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        )}

        {/* Course Summary */}
        {activeEnrollments.length > 0 && (
          <Card>
            <CardContent className="p-6">
              <h3 className="text-lg font-semibold mb-4">Course Summary</h3>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="text-center">
                  <p className="text-2xl font-bold text-primary">{activeEnrollments.length}</p>
                  <p className="text-sm text-muted-foreground">Active Courses</p>
                </div>
                <div className="text-center">
                  <p className="text-2xl font-bold text-secondary">
                    {Math.round(activeEnrollments.reduce((sum, e) => sum + (e.progress || 0), 0) / activeEnrollments.length)}%
                  </p>
                  <p className="text-sm text-muted-foreground">Average Progress</p>
                </div>
                <div className="text-center">
                  <p className="text-2xl font-bold text-accent">
                    {activeEnrollments.filter(e => e.grade && e.grade.startsWith('A')).length}
                  </p>
                  <p className="text-sm text-muted-foreground">A Grades</p>
                </div>
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </StudentLayout>
  );
}
