import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { BookOpen, CalendarCheck, CheckCircle, Star, AlertCircle, Clock } from "lucide-react";
import StudentLayout from "@/components/student-layout";
import { AuthService } from "@/lib/auth";
import type { EnrollmentWithDetails, PaymentWithDetails, AttendanceWithDetails } from "@shared/schema";

export default function StudentDashboard() {
  const { data: auth } = useQuery({
    queryKey: ['/api/auth/me'],
    queryFn: () => AuthService.getCurrentUser(),
  });

  const studentId = auth?.student?.id;

  const { data: enrollments = [] } = useQuery<EnrollmentWithDetails[]>({
    queryKey: ['/api/enrollments', studentId],
    enabled: !!studentId,
  });

  const { data: payments = [] } = useQuery<PaymentWithDetails[]>({
    queryKey: ['/api/payments', studentId],
    enabled: !!studentId,
  });

  const { data: attendance = [] } = useQuery<AttendanceWithDetails[]>({
    queryKey: ['/api/attendance', studentId],
    enabled: !!studentId,
  });

  const activeEnrollments = enrollments.filter(e => e.status === 'active');
  const presentCount = attendance.filter(a => a.status === 'present').length;
  const totalAttendance = attendance.length;
  const attendanceRate = totalAttendance > 0 ? Math.round((presentCount / totalAttendance) * 100) : 0;

  const paidPayments = payments.filter(p => p.status === 'paid');
  const pendingPayments = payments.filter(p => p.status === 'pending' || p.status === 'overdue');
  const paymentStatus = pendingPayments.length === 0 ? 'Up to Date' : 'Pending';

  // Calculate overall grade (placeholder calculation)
  const calculateOverallGrade = () => {
    const grades = activeEnrollments.filter(e => e.grade).map(e => e.grade);
    if (grades.length === 0) return 'N/A';
    
    // Simple grade calculation based on common grades
    const gradePoints: { [key: string]: number } = {
      'A+': 4.0, 'A': 4.0, 'A-': 3.7,
      'B+': 3.3, 'B': 3.0, 'B-': 2.7,
      'C+': 2.3, 'C': 2.0, 'C-': 1.7,
      'D': 1.0, 'F': 0.0
    };
    
    const avgPoints = grades.reduce((sum, grade) => sum + (gradePoints[grade!] || 0), 0) / grades.length;
    
    if (avgPoints >= 3.7) return 'A-';
    if (avgPoints >= 3.3) return 'B+';
    if (avgPoints >= 3.0) return 'B';
    if (avgPoints >= 2.7) return 'B-';
    return 'C+';
  };

  const studentName = auth?.student?.firstName || 'Student';

  // Get today's schedule (simulated)
  const getTodaysSchedule = () => {
    const today = new Date().toISOString().split('T')[0];
    const todaysAttendance = attendance.filter(a => a.date === today);
    
    return activeEnrollments.map((enrollment, index) => ({
      ...enrollment,
      time: ['10:00 AM - 11:30 AM', '2:00 PM - 4:00 PM', '9:00 AM - 10:30 AM'][index % 3],
      status: todaysAttendance.find(a => a.courseId === enrollment.courseId) ? 'completed' : 'upcoming'
    }));
  };

  const schedule = getTodaysSchedule();

  return (
    <StudentLayout title={`Welcome back, ${studentName}!`} description="Here's your academic overview for today">
      <div className="space-y-6">
        {/* Student Stats */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Active Courses</p>
                  <p className="text-2xl font-bold">{activeEnrollments.length}</p>
                </div>
                <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center">
                  <BookOpen className="h-6 w-6 text-primary" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Attendance Rate</p>
                  <p className="text-2xl font-bold">{attendanceRate}%</p>
                </div>
                <div className="w-12 h-12 bg-secondary/10 rounded-lg flex items-center justify-center">
                  <CalendarCheck className="h-6 w-6 text-secondary" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Payment Status</p>
                  <p className="text-xl font-bold text-secondary">{paymentStatus}</p>
                </div>
                <div className="w-12 h-12 bg-secondary/10 rounded-lg flex items-center justify-center">
                  <CheckCircle className="h-6 w-6 text-secondary" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Overall Grade</p>
                  <p className="text-2xl font-bold">{calculateOverallGrade()}</p>
                </div>
                <div className="w-12 h-12 bg-accent/10 rounded-lg flex items-center justify-center">
                  <Star className="h-6 w-6 text-accent" />
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Quick Actions & Schedule */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <Card>
            <CardHeader>
              <CardTitle>Today's Schedule</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {schedule.length > 0 ? (
                schedule.slice(0, 3).map((item) => (
                  <div key={item.id} className={`flex items-center space-x-4 p-3 rounded-lg ${
                    item.status === 'completed' ? 'bg-primary/5' : 'bg-muted'
                  }`}>
                    <div className={`w-3 h-3 rounded-full ${
                      item.status === 'completed' ? 'bg-primary' : 'bg-gray-300'
                    }`}></div>
                    <div className="flex-1">
                      <p className="font-medium">{item.course.name}</p>
                      <p className="text-sm text-muted-foreground">{item.time}</p>
                    </div>
                    {item.status === 'completed' && (
                      <Badge className="bg-primary text-white">Completed</Badge>
                    )}
                  </div>
                ))
              ) : (
                <div className="text-center py-4">
                  <p className="text-muted-foreground">No classes scheduled for today</p>
                </div>
              )}
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Recent Announcements</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="p-3 bg-blue-50 rounded-lg border-l-4 border-primary">
                <p className="font-medium text-sm">Assignment Reminder</p>
                <p className="text-muted-foreground text-xs mt-1">
                  Don't forget to submit your assignments by the due date
                </p>
                <p className="text-muted-foreground text-xs mt-2">2 hours ago</p>
              </div>

              <div className="p-3 bg-green-50 rounded-lg border-l-4 border-secondary">
                <p className="font-medium text-sm">Grade Update</p>
                <p className="text-muted-foreground text-xs mt-1">
                  New grades have been posted for recent assessments
                </p>
                <p className="text-muted-foreground text-xs mt-2">1 day ago</p>
              </div>

              <div className="p-3 bg-yellow-50 rounded-lg border-l-4 border-warning">
                <p className="font-medium text-sm">Schedule Notice</p>
                <p className="text-muted-foreground text-xs mt-1">
                  Please check for any schedule changes this week
                </p>
                <p className="text-muted-foreground text-xs mt-2">2 days ago</p>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Recent Activity */}
        <Card>
          <CardHeader>
            <CardTitle>Recent Activity</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {attendance.slice(0, 5).map((record) => (
                <div key={record.id} className="flex items-center space-x-3">
                  <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
                    record.status === 'present' 
                      ? 'bg-green-100 text-green-600' 
                      : 'bg-red-100 text-red-600'
                  }`}>
                    {record.status === 'present' ? (
                      <CheckCircle className="h-4 w-4" />
                    ) : (
                      <AlertCircle className="h-4 w-4" />
                    )}
                  </div>
                  <div className="flex-1">
                    <p className="font-medium">{record.course.name}</p>
                    <p className="text-sm text-muted-foreground">
                      {record.status === 'present' ? 'Attended' : 'Missed'} class on {new Date(record.date).toLocaleDateString()}
                    </p>
                  </div>
                  <span className="text-xs text-muted-foreground">
                    {new Date(record.date).toLocaleDateString()}
                  </span>
                </div>
              ))}
              
              {attendance.length === 0 && (
                <div className="text-center py-4">
                  <p className="text-muted-foreground">No recent activity</p>
                </div>
              )}
            </div>
          </CardContent>
        </Card>
      </div>
    </StudentLayout>
  );
}
