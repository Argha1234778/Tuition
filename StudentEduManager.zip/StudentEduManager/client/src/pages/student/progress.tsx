import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Trophy, Star, Medal, TrendingUp, BookOpen, Clock, AlertCircle, CheckCircle } from "lucide-react";
import StudentLayout from "@/components/student-layout";
import { AuthService } from "@/lib/auth";
import type { EnrollmentWithDetails } from "@shared/schema";

export default function StudentProgress() {
  const { data: auth } = useQuery({
    queryKey: ['/api/auth/me'],
    queryFn: () => AuthService.getCurrentUser(),
  });

  const studentId = auth?.student?.id;

  const { data: enrollments = [], isLoading } = useQuery<EnrollmentWithDetails[]>({
    queryKey: ['/api/enrollments', studentId],
    enabled: !!studentId,
  });

  const activeEnrollments = enrollments.filter(e => e.status === 'active');

  // Calculate overall progress
  const overallProgress = activeEnrollments.length > 0 
    ? Math.round(activeEnrollments.reduce((sum, e) => sum + (e.progress || 0), 0) / activeEnrollments.length)
    : 0;

  // Generate achievements based on progress and grades
  const getAchievements = () => {
    const achievements = [];
    
    // Check for high grades
    const aGrades = activeEnrollments.filter(e => e.grade && e.grade.startsWith('A')).length;
    if (aGrades > 0) {
      achievements.push({
        id: 1,
        title: "Top Performer",
        description: aGrades > 1 ? "Multiple A grades" : "First A grade",
        icon: Star,
        color: "bg-yellow-100 text-yellow-600"
      });
    }

    // Check for completion
    const completedCourses = activeEnrollments.filter(e => e.progress === 100).length;
    if (completedCourses > 0) {
      achievements.push({
        id: 2,
        title: "Course Completion",
        description: `Completed ${completedCourses} course${completedCourses > 1 ? 's' : ''}`,
        icon: Trophy,
        color: "bg-green-100 text-green-600"
      });
    }

    // Check for consistent progress
    const highProgressCourses = activeEnrollments.filter(e => (e.progress || 0) >= 75).length;
    if (highProgressCourses >= 2) {
      achievements.push({
        id: 3,
        title: "Consistent Learner",
        description: "High progress across multiple courses",
        icon: Medal,
        color: "bg-blue-100 text-blue-600"
      });
    }

    return achievements;
  };

  const achievements = getAchievements();

  // Generate upcoming assignments/deadlines (simulated based on course progress)
  const getUpcomingTasks = () => {
    return activeEnrollments
      .filter(e => (e.progress || 0) < 100)
      .map((enrollment, index) => {
        const daysLeft = [5, 10, 15, 21][index % 4];
        const taskTypes = ['Assignment', 'Quiz', 'Project', 'Exam'];
        const priorities = ['high', 'medium', 'low'];
        
        return {
          id: enrollment.id,
          title: `${taskTypes[index % taskTypes.length]} - ${enrollment.course.name}`,
          course: enrollment.course.name,
          dueDate: new Date(Date.now() + daysLeft * 24 * 60 * 60 * 1000).toLocaleDateString(),
          daysLeft,
          priority: priorities[index % priorities.length] as 'high' | 'medium' | 'low'
        };
      })
      .sort((a, b) => a.daysLeft - b.daysLeft);
  };

  const upcomingTasks = getUpcomingTasks();

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'high': return 'bg-red-100 text-red-800';
      case 'medium': return 'bg-yellow-100 text-yellow-800';
      case 'low': return 'bg-green-100 text-green-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getPriorityIcon = (daysLeft: number) => {
    if (daysLeft <= 7) return <AlertCircle className="h-4 w-4 text-red-500" />;
    if (daysLeft <= 14) return <Clock className="h-4 w-4 text-yellow-500" />;
    return <BookOpen className="h-4 w-4 text-green-500" />;
  };

  if (isLoading) {
    return (
      <StudentLayout title="Academic Progress" description="Loading your progress data...">
        <div className="flex items-center justify-center h-64">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
        </div>
      </StudentLayout>
    );
  }

  return (
    <StudentLayout title="Academic Progress" description="Monitor your learning progress and achievements">
      <div className="space-y-6">
        {/* Progress Overview */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2">
            <Card>
              <CardHeader>
                <CardTitle>Course Progress</CardTitle>
              </CardHeader>
              <CardContent>
                {activeEnrollments.length > 0 ? (
                  <div className="space-y-6">
                    {activeEnrollments.map((enrollment) => {
                      const progress = enrollment.progress || 0;
                      const grade = enrollment.grade || 'N/A';
                      
                      return (
                        <div key={enrollment.id}>
                          <div className="flex justify-between items-center mb-2">
                            <span className="font-medium">{enrollment.course.name}</span>
                            <span className="text-sm text-muted-foreground">
                              {progress}% Complete
                            </span>
                          </div>
                          <Progress value={progress} className="h-3 mb-2" />
                          <div className="flex justify-between text-sm text-muted-foreground">
                            <span>Current Grade: {grade}</span>
                            <span>
                              Duration: {enrollment.course.duration} weeks
                            </span>
                          </div>
                        </div>
                      );
                    })}
                    
                    <div className="pt-4 border-t border-border">
                      <div className="flex justify-between items-center mb-2">
                        <span className="font-semibold">Overall Progress</span>
                        <span className="text-sm font-medium">{overallProgress}%</span>
                      </div>
                      <Progress value={overallProgress} className="h-4" />
                    </div>
                  </div>
                ) : (
                  <div className="text-center py-8">
                    <BookOpen className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                    <p className="text-muted-foreground">No active courses to track</p>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>

          <Card>
            <CardHeader>
              <CardTitle>Achievements</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {achievements.length > 0 ? (
                  achievements.map((achievement) => {
                    const Icon = achievement.icon;
                    return (
                      <div key={achievement.id} className="flex items-center space-x-3 p-3 bg-muted rounded-lg">
                        <div className={`w-10 h-10 rounded-full flex items-center justify-center ${achievement.color}`}>
                          <Icon className="h-5 w-5" />
                        </div>
                        <div>
                          <p className="font-medium text-sm">{achievement.title}</p>
                          <p className="text-xs text-muted-foreground">{achievement.description}</p>
                        </div>
                      </div>
                    );
                  })
                ) : (
                  <div className="text-center py-4">
                    <Trophy className="h-8 w-8 text-muted-foreground mx-auto mb-2" />
                    <p className="text-sm text-muted-foreground">No achievements yet</p>
                    <p className="text-xs text-muted-foreground">Keep working to earn your first achievement!</p>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Performance Summary */}
        <Card>
          <CardHeader>
            <CardTitle>Performance Summary</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <div className="text-center">
                <div className="text-2xl font-bold text-primary">{activeEnrollments.length}</div>
                <p className="text-sm text-muted-foreground">Active Courses</p>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-secondary">{overallProgress}%</div>
                <p className="text-sm text-muted-foreground">Average Progress</p>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-accent">
                  {activeEnrollments.filter(e => e.grade && e.grade.startsWith('A')).length}
                </div>
                <p className="text-sm text-muted-foreground">A Grades</p>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-warning">{achievements.length}</div>
                <p className="text-sm text-muted-foreground">Achievements</p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Upcoming Tasks */}
        <Card>
          <CardHeader>
            <CardTitle>Upcoming Tasks & Deadlines</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {upcomingTasks.length > 0 ? (
                upcomingTasks.map((task) => (
                  <div key={task.id} className="flex items-center justify-between p-4 border border-border rounded-lg">
                    <div className="flex items-center space-x-3">
                      {getPriorityIcon(task.daysLeft)}
                      <div>
                        <p className="font-medium">{task.title}</p>
                        <p className="text-sm text-muted-foreground">{task.course}</p>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="text-sm font-medium">Due: {task.dueDate}</p>
                      <div className="flex items-center space-x-2 mt-1">
                        <Badge className={getPriorityColor(task.priority)}>
                          {task.priority}
                        </Badge>
                        <span className="text-xs text-muted-foreground">
                          {task.daysLeft} days left
                        </span>
                      </div>
                    </div>
                  </div>
                ))
              ) : (
                <div className="text-center py-8">
                  <CheckCircle className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                  <p className="text-muted-foreground">No upcoming tasks</p>
                </div>
              )}
            </div>
          </CardContent>
        </Card>
      </div>
    </StudentLayout>
  );
}
