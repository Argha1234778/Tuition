import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Separator } from "@/components/ui/separator";
import { User, Mail, Phone, MapPin, Calendar, Loader2 } from "lucide-react";
import StudentLayout from "@/components/student-layout";
import { AuthService } from "@/lib/auth";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import type { Student } from "@shared/schema";

export default function StudentProfile() {
  const { toast } = useToast();
  
  const { data: auth } = useQuery({
    queryKey: ['/api/auth/me'],
    queryFn: () => AuthService.getCurrentUser(),
  });

  const student = auth?.student;
  
  const [isEditing, setIsEditing] = useState(false);
  const [formData, setFormData] = useState({
    firstName: student?.firstName || '',
    lastName: student?.lastName || '',
    email: student?.email || '',
    phone: student?.phone || '',
    address: student?.address || '',
  });

  const updateProfileMutation = useMutation({
    mutationFn: async (data: any) => {
      if (!student?.id) throw new Error('Student ID not found');
      const response = await apiRequest('PUT', `/api/students/${student.id}`, data);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/auth/me'] });
      toast({
        title: "Success",
        description: "Profile updated successfully",
      });
      setIsEditing(false);
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to update profile",
        variant: "destructive",
      });
    },
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    await updateProfileMutation.mutateAsync(formData);
  };

  const handleCancel = () => {
    setFormData({
      firstName: student?.firstName || '',
      lastName: student?.lastName || '',
      email: student?.email || '',
      phone: student?.phone || '',
      address: student?.address || '',
    });
    setIsEditing(false);
  };

  if (!student) {
    return (
      <StudentLayout title="My Profile" description="Loading profile...">
        <div className="flex items-center justify-center h-64">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
        </div>
      </StudentLayout>
    );
  }

  return (
    <StudentLayout title="My Profile" description="Manage your personal information and settings">
      <div className="space-y-6">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Profile Card */}
          <Card>
            <CardContent className="pt-6">
              <div className="text-center">
                <div className="w-24 h-24 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
                  <span className="text-primary text-2xl font-bold">
                    {student.firstName[0]}{student.lastName[0]}
                  </span>
                </div>
                <h3 className="text-xl font-semibold">{student.firstName} {student.lastName}</h3>
                <p className="text-muted-foreground">Student ID: {student.studentId}</p>
                <p className="text-muted-foreground text-sm mt-2">
                  Member since {new Date(student.enrollmentDate).toLocaleDateString('en-US', { 
                    month: 'long', 
                    year: 'numeric' 
                  })}
                </p>
                
                <div className="mt-4 pt-4 border-t border-border">
                  <div className="flex items-center justify-center space-x-2 text-sm text-muted-foreground">
                    <span className={`inline-block w-2 h-2 rounded-full ${
                      student.status === 'active' ? 'bg-green-500' : 'bg-gray-400'
                    }`}></span>
                    <span className="capitalize">{student.status}</span>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Contact Information */}
          <div className="lg:col-span-2">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between">
                <CardTitle>Personal Information</CardTitle>
                {!isEditing ? (
                  <Button onClick={() => setIsEditing(true)} variant="outline">
                    Edit Profile
                  </Button>
                ) : (
                  <div className="space-x-2">
                    <Button 
                      onClick={handleCancel} 
                      variant="outline" 
                      disabled={updateProfileMutation.isPending}
                    >
                      Cancel
                    </Button>
                    <Button 
                      onClick={handleSubmit} 
                      disabled={updateProfileMutation.isPending}
                    >
                      {updateProfileMutation.isPending ? (
                        <>
                          <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                          Saving...
                        </>
                      ) : (
                        'Save Changes'
                      )}
                    </Button>
                  </div>
                )}
              </CardHeader>
              <CardContent>
                <form onSubmit={handleSubmit} className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="firstName" className="flex items-center space-x-2">
                        <User className="h-4 w-4" />
                        <span>First Name</span>
                      </Label>
                      {isEditing ? (
                        <Input
                          id="firstName"
                          value={formData.firstName}
                          onChange={(e) => setFormData({ ...formData, firstName: e.target.value })}
                          disabled={updateProfileMutation.isPending}
                        />
                      ) : (
                        <p className="text-sm py-2 px-3 bg-muted rounded-md">{student.firstName}</p>
                      )}
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="lastName" className="flex items-center space-x-2">
                        <User className="h-4 w-4" />
                        <span>Last Name</span>
                      </Label>
                      {isEditing ? (
                        <Input
                          id="lastName"
                          value={formData.lastName}
                          onChange={(e) => setFormData({ ...formData, lastName: e.target.value })}
                          disabled={updateProfileMutation.isPending}
                        />
                      ) : (
                        <p className="text-sm py-2 px-3 bg-muted rounded-md">{student.lastName}</p>
                      )}
                    </div>
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="email" className="flex items-center space-x-2">
                      <Mail className="h-4 w-4" />
                      <span>Email</span>
                    </Label>
                    {isEditing ? (
                      <Input
                        id="email"
                        type="email"
                        value={formData.email}
                        onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                        disabled={updateProfileMutation.isPending}
                      />
                    ) : (
                      <p className="text-sm py-2 px-3 bg-muted rounded-md">{student.email}</p>
                    )}
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="phone" className="flex items-center space-x-2">
                      <Phone className="h-4 w-4" />
                      <span>Phone</span>
                    </Label>
                    {isEditing ? (
                      <Input
                        id="phone"
                        type="tel"
                        value={formData.phone}
                        onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                        placeholder="Enter phone number"
                        disabled={updateProfileMutation.isPending}
                      />
                    ) : (
                      <p className="text-sm py-2 px-3 bg-muted rounded-md">
                        {student.phone || 'Not provided'}
                      </p>
                    )}
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="address" className="flex items-center space-x-2">
                      <MapPin className="h-4 w-4" />
                      <span>Address</span>
                    </Label>
                    {isEditing ? (
                      <Textarea
                        id="address"
                        rows={3}
                        value={formData.address}
                        onChange={(e) => setFormData({ ...formData, address: e.target.value })}
                        placeholder="Enter your address"
                        disabled={updateProfileMutation.isPending}
                      />
                    ) : (
                      <p className="text-sm py-2 px-3 bg-muted rounded-md">
                        {student.address || 'Not provided'}
                      </p>
                    )}
                  </div>

                  <Separator />

                  <div className="space-y-2">
                    <Label className="flex items-center space-x-2">
                      <Calendar className="h-4 w-4" />
                      <span>Enrollment Date</span>
                    </Label>
                    <p className="text-sm py-2 px-3 bg-muted rounded-md">
                      {new Date(student.enrollmentDate).toLocaleDateString('en-US', {
                        weekday: 'long',
                        year: 'numeric',
                        month: 'long',
                        day: 'numeric'
                      })}
                    </p>
                  </div>
                </form>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Account Information */}
        <Card>
          <CardHeader>
            <CardTitle>Account Information</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <h4 className="font-medium mb-3">Login Credentials</h4>
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Username:</span>
                    <span className="font-medium">{auth?.user?.username}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Account Type:</span>
                    <span className="font-medium capitalize">{auth?.user?.role}</span>
                  </div>
                </div>
              </div>
              
              <div>
                <h4 className="font-medium mb-3">Account Status</h4>
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Status:</span>
                    <span className={`font-medium capitalize ${
                      student.status === 'active' ? 'text-green-600' : 'text-gray-600'
                    }`}>
                      {student.status}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Last Login:</span>
                    <span className="font-medium">Recently</span>
                  </div>
                </div>
              </div>
            </div>

            <Separator className="my-4" />

            <div className="space-y-3">
              <h4 className="font-medium">Important Notes</h4>
              <ul className="text-sm text-muted-foreground space-y-1">
                <li>• Contact the administration office to change your password</li>
                <li>• Your student ID is permanent and cannot be changed</li>
                <li>• Profile changes may take up to 24 hours to reflect in all systems</li>
                <li>• For any issues with your account, contact support at admin@edumanage.com</li>
              </ul>
            </div>
          </CardContent>
        </Card>
      </div>
    </StudentLayout>
  );
}
