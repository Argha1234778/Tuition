import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { CheckCircle, XCircle, Users, CalendarCheck, TrendingUp } from "lucide-react";
import StudentLayout from "@/components/student-layout";
import { AuthService } from "@/lib/auth";
import type { AttendanceWithDetails, EnrollmentWithDetails } from "@shared/schema";

export default function StudentAttendance() {
  const { data: auth } = useQuery({
    queryKey: ['/api/auth/me'],
    queryFn: () => AuthService.getCurrentUser(),
  });

  const studentId = auth?.student?.id;

  const { data: attendance = [], isLoading } = useQuery<AttendanceWithDetails[]>({
    queryKey: ['/api/attendance', studentId],
    enabled: !!studentId,
  });

  const { data: enrollments = [] } = useQuery<EnrollmentWithDetails[]>({
    queryKey: ['/api/enrollments', { studentId }],
    enabled: !!studentId,
  });

  const presentCount = attendance.filter(a => a.status === 'present').length;
  const absentCount = attendance.filter(a => a.status === 'absent').length;
  const totalClasses = attendance.length;
  const overallAttendanceRate = totalClasses > 0 ? Math.round((presentCount / totalClasses) * 100) : 0;

  // Calculate attendance by course
  const getCourseAttendance = () => {
    const courseAttendance = new Map();
    
    enrollments.forEach(enrollment => {
      const courseAttendanceRecords = attendance.filter(a => a.courseId === enrollment.courseId);
      const coursePresent = courseAttendanceRecords.filter(a => a.status === 'present').length;
      const courseTotal = courseAttendanceRecords.length;
      const courseRate = courseTotal > 0 ? Math.round((coursePresent / courseTotal) * 100) : 0;
      
      courseAttendance.set(enrollment.courseId, {
        courseName: enrollment.course.name,
        present: coursePresent,
        total: courseTotal,
        rate: courseRate
      });
    });
    
    return Array.from(courseAttendance.values());
  };

  const courseAttendanceData = getCourseAttendance();

  // Calculate recent attendance trends
  const getAttendanceTrends = () => {
    const now = new Date();
    const thisWeek = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
    const thisMonth = new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000);

    const weeklyAttendance = attendance.filter(a => new Date(a.date) >= thisWeek);
    const monthlyAttendance = attendance.filter(a => new Date(a.date) >= thisMonth);

    const weeklyPresent = weeklyAttendance.filter(a => a.status === 'present').length;
    const monthlyPresent = monthlyAttendance.filter(a => a.status === 'present').length;

    return {
      weekly: weeklyAttendance.length > 0 ? Math.round((weeklyPresent / weeklyAttendance.length) * 100) : 0,
      monthly: monthlyAttendance.length > 0 ? Math.round((monthlyPresent / monthlyAttendance.length) * 100) : 0,
    };
  };

  const trends = getAttendanceTrends();

  if (isLoading) {
    return (
      <StudentLayout title="My Attendance" description="Loading your attendance records...">
        <div className="flex items-center justify-center h-64">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
        </div>
      </StudentLayout>
    );
  }

  return (
    <StudentLayout title="My Attendance" description="Track your class attendance and patterns">
      <div className="space-y-6">
        {/* Attendance Overview */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <Card>
            <CardHeader>
              <CardTitle>Attendance Summary</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                <div className="text-center">
                  <div className="text-4xl font-bold text-secondary mb-2">{overallAttendanceRate}%</div>
                  <p className="text-muted-foreground">Overall Attendance Rate</p>
                </div>

                <div className="grid grid-cols-2 gap-4 text-center">
                  <div>
                    <div className="text-2xl font-bold text-green-600">{presentCount}</div>
                    <p className="text-sm text-muted-foreground">Classes Attended</p>
                  </div>
                  <div>
                    <div className="text-2xl font-bold text-red-600">{absentCount}</div>
                    <p className="text-sm text-muted-foreground">Classes Missed</p>
                  </div>
                </div>

                <div className="space-y-4">
                  <div>
                    <div className="flex justify-between text-sm mb-2">
                      <span className="text-muted-foreground">This Week</span>
                      <span className="font-medium">{trends.weekly}%</span>
                    </div>
                    <Progress value={trends.weekly} className="h-2" />
                  </div>
                  
                  <div>
                    <div className="flex justify-between text-sm mb-2">
                      <span className="text-muted-foreground">This Month</span>
                      <span className="font-medium">{trends.monthly}%</span>
                    </div>
                    <Progress value={trends.monthly} className="h-2" />
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Course-wise Attendance</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {courseAttendanceData.length > 0 ? (
                  courseAttendanceData.map((course, index) => (
                    <div key={index} className="space-y-2">
                      <div className="flex justify-between items-center">
                        <span className="font-medium text-sm">{course.courseName}</span>
                        <span className="text-sm text-muted-foreground">
                          {course.present}/{course.total} ({course.rate}%)
                        </span>
                      </div>
                      <Progress value={course.rate} className="h-2" />
                    </div>
                  ))
                ) : (
                  <div className="text-center py-4">
                    <p className="text-muted-foreground">No attendance records available</p>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Attendance Status */}
        <Card>
          <CardHeader>
            <CardTitle>Attendance Status</CardTitle>
          </CardHeader>
          <CardContent>
            {overallAttendanceRate >= 90 ? (
              <div className="flex items-center space-x-3 p-4 bg-green-50 rounded-lg border border-green-200">
                <CheckCircle className="h-6 w-6 text-green-600" />
                <div>
                  <h3 className="font-medium text-green-900">Excellent Attendance</h3>
                  <p className="text-sm text-green-700">
                    Great job! Your attendance rate is {overallAttendanceRate}%. Keep up the good work!
                  </p>
                </div>
              </div>
            ) : overallAttendanceRate >= 75 ? (
              <div className="flex items-center space-x-3 p-4 bg-yellow-50 rounded-lg border border-yellow-200">
                <CalendarCheck className="h-6 w-6 text-yellow-600" />
                <div>
                  <h3 className="font-medium text-yellow-900">Good Attendance</h3>
                  <p className="text-sm text-yellow-700">
                    Your attendance rate is {overallAttendanceRate}%. Try to attend more classes to improve your performance.
                  </p>
                </div>
              </div>
            ) : (
              <div className="flex items-center space-x-3 p-4 bg-red-50 rounded-lg border border-red-200">
                <XCircle className="h-6 w-6 text-red-600" />
                <div>
                  <h3 className="font-medium text-red-900">Attendance Needs Improvement</h3>
                  <p className="text-sm text-red-700">
                    Your attendance rate is {overallAttendanceRate}%. Please focus on attending classes regularly to improve your academic performance.
                  </p>
                </div>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Recent Attendance */}
        <Card>
          <CardHeader>
            <CardTitle>Recent Attendance</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {attendance.length > 0 ? (
                attendance.slice(0, 10).map((record) => (
                  <div key={record.id} className={`flex items-center justify-between p-3 rounded-lg ${
                    record.status === 'present' ? 'bg-green-50' : 'bg-red-50'
                  }`}>
                    <div className="flex items-center space-x-3">
                      <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
                        record.status === 'present' 
                          ? 'bg-green-100 text-green-600' 
                          : 'bg-red-100 text-red-600'
                      }`}>
                        {record.status === 'present' ? (
                          <CheckCircle className="h-4 w-4" />
                        ) : (
                          <XCircle className="h-4 w-4" />
                        )}
                      </div>
                      <div>
                        <p className="font-medium">{record.course.name}</p>
                        <p className="text-sm text-muted-foreground">
                          {new Date(record.date).toLocaleDateString('en-US', { 
                            weekday: 'long', 
                            year: 'numeric', 
                            month: 'long', 
                            day: 'numeric' 
                          })}
                        </p>
                      </div>
                    </div>
                    <Badge className={
                      record.status === 'present' 
                        ? "bg-green-100 text-green-800" 
                        : "bg-red-100 text-red-800"
                    }>
                      {record.status.charAt(0).toUpperCase() + record.status.slice(1)}
                    </Badge>
                  </div>
                ))
              ) : (
                <div className="text-center py-8">
                  <CalendarCheck className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                  <p className="text-muted-foreground">No attendance records available</p>
                </div>
              )}
            </div>
          </CardContent>
        </Card>
      </div>
    </StudentLayout>
  );
}
