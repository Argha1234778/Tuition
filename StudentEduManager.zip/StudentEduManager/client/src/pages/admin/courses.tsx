import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Plus, Edit, Eye, BookOpen, Calculator, Atom, FlaskConical } from "lucide-react";
import AdminLayout from "@/components/admin-layout";
import CourseModal from "@/components/course-modal";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import type { Course, EnrollmentWithDetails } from "@shared/schema";

const getCourseIcon = (courseName: string) => {
  const name = courseName.toLowerCase();
  if (name.includes('math')) return Calculator;
  if (name.includes('physics')) return Atom;
  if (name.includes('chemistry')) return FlaskConical;
  return BookOpen;
};

export default function AdminCourses() {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const { toast } = useToast();

  const { data: courses = [], isLoading } = useQuery<Course[]>({
    queryKey: ['/api/courses'],
  });

  const { data: enrollments = [] } = useQuery<EnrollmentWithDetails[]>({
    queryKey: ['/api/enrollments'],
  });

  const updateCourseMutation = useMutation({
    mutationFn: async ({ id, data }: { id: number; data: any }) => {
      const response = await apiRequest('PUT', `/api/courses/${id}`, data);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/courses'] });
      toast({
        title: "Success",
        description: "Course updated successfully",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to update course",
        variant: "destructive",
      });
    },
  });

  const getCourseEnrollmentCount = (courseId: number) => {
    return enrollments.filter(e => e.courseId === courseId && e.status === 'active').length;
  };

  const getStatusBadge = (status: string) => {
    const variants = {
      active: "default",
      draft: "secondary",
      archived: "outline"
    } as const;
    
    const colors = {
      active: "bg-green-100 text-green-800",
      draft: "bg-yellow-100 text-yellow-800",
      archived: "bg-gray-100 text-gray-800"
    } as const;
    
    return (
      <Badge className={colors[status as keyof typeof colors] || colors.draft}>
        {status.charAt(0).toUpperCase() + status.slice(1)}
      </Badge>
    );
  };

  const handleStatusChange = async (courseId: number, newStatus: string) => {
    await updateCourseMutation.mutateAsync({
      id: courseId,
      data: { status: newStatus }
    });
  };

  if (isLoading) {
    return (
      <AdminLayout title="Course Management" description="Loading courses...">
        <div className="flex items-center justify-center h-64">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
        </div>
      </AdminLayout>
    );
  }

  return (
    <AdminLayout title="Course Management" description="Create and manage courses">
      <div className="space-y-6">
        {/* Header Actions */}
        <div className="flex justify-between items-center">
          <div className="flex items-center space-x-2">
            <h3 className="text-lg font-semibold">Courses ({courses.length})</h3>
          </div>
          <Button onClick={() => setIsModalOpen(true)}>
            <Plus className="h-4 w-4 mr-2" />
            Add Course
          </Button>
        </div>

        {/* Courses Grid */}
        {courses.length === 0 ? (
          <Card>
            <CardContent className="text-center py-8">
              <p className="text-muted-foreground">No courses created yet</p>
            </CardContent>
          </Card>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {courses.map((course) => {
              const Icon = getCourseIcon(course.name);
              const enrollmentCount = getCourseEnrollmentCount(course.id);
              
              return (
                <Card key={course.id} className="card-hover">
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between mb-4">
                      <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center">
                        <Icon className="h-6 w-6 text-primary" />
                      </div>
                      {getStatusBadge(course.status)}
                    </div>
                    
                    <h3 className="text-lg font-semibold mb-2">{course.name}</h3>
                    <p className="text-muted-foreground text-sm mb-4 line-clamp-2">
                      {course.description || "No description available"}
                    </p>
                    
                    <div className="space-y-2 text-sm">
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Students:</span>
                        <span className="font-medium">
                          {enrollmentCount}/{course.maxStudents}
                        </span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Duration:</span>
                        <span className="font-medium">{course.duration} weeks</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Fee:</span>
                        <span className="font-medium">${course.fee}</span>
                      </div>
                    </div>
                    
                    <div className="flex space-x-2 mt-4">
                      {course.status === 'draft' ? (
                        <Button
                          className="flex-1 bg-secondary hover:bg-secondary/90 text-white"
                          onClick={() => handleStatusChange(course.id, 'active')}
                          disabled={updateCourseMutation.isPending}
                        >
                          Publish Course
                        </Button>
                      ) : (
                        <Button className="flex-1" variant="outline">
                          <Edit className="h-4 w-4 mr-2" />
                          Edit Course
                        </Button>
                      )}
                      <Button variant="outline" size="sm">
                        <Eye className="h-4 w-4" />
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        )}
      </div>

      <CourseModal open={isModalOpen} onOpenChange={setIsModalOpen} />
    </AdminLayout>
  );
}
