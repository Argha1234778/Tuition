import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Users, BookOpen, DollarSign, Clock, ArrowUp, TriangleAlert } from "lucide-react";
import AdminLayout from "@/components/admin-layout";
import type { StudentWithUser, Course, PaymentWithDetails } from "@shared/schema";

export default function AdminDashboard() {
  const { data: students = [] } = useQuery<StudentWithUser[]>({
    queryKey: ['/api/students'],
  });

  const { data: courses = [] } = useQuery<Course[]>({
    queryKey: ['/api/courses'],
  });

  const { data: payments = [] } = useQuery<PaymentWithDetails[]>({
    queryKey: ['/api/payments'],
  });

  const activeStudents = students.filter(s => s.status === 'active').length;
  const activeCourses = courses.filter(c => c.status === 'active').length;
  const paidPayments = payments.filter(p => p.status === 'paid');
  const pendingPayments = payments.filter(p => p.status === 'pending').length;
  const overduePayments = payments.filter(p => p.status === 'overdue').length;
  
  const totalRevenue = paidPayments.reduce((sum, payment) => sum + Number(payment.amount), 0);
  const recentStudents = students.slice(0, 3);

  return (
    <AdminLayout title="Dashboard Overview" description="Welcome back, Admin. Here's what's happening today.">
      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <Card className="card-hover">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Total Students</p>
                <p className="text-2xl font-bold">{activeStudents}</p>
                <p className="text-sm text-green-600 flex items-center mt-1">
                  <ArrowUp className="h-3 w-3 mr-1" />
                  Active students
                </p>
              </div>
              <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center">
                <Users className="h-6 w-6 text-primary" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="card-hover">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Active Courses</p>
                <p className="text-2xl font-bold">{activeCourses}</p>
                <p className="text-sm text-green-600 flex items-center mt-1">
                  <ArrowUp className="h-3 w-3 mr-1" />
                  Running courses
                </p>
              </div>
              <div className="w-12 h-12 bg-secondary/10 rounded-lg flex items-center justify-center">
                <BookOpen className="h-6 w-6 text-secondary" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="card-hover">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Revenue This Month</p>
                <p className="text-2xl font-bold">${totalRevenue.toLocaleString()}</p>
                <p className="text-sm text-green-600 flex items-center mt-1">
                  <ArrowUp className="h-3 w-3 mr-1" />
                  Total collected
                </p>
              </div>
              <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
                <DollarSign className="h-6 w-6 text-green-600" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="card-hover">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Pending Payments</p>
                <p className="text-2xl font-bold">{pendingPayments + overduePayments}</p>
                <p className="text-sm text-red-500 flex items-center mt-1">
                  <TriangleAlert className="h-3 w-3 mr-1" />
                  Needs attention
                </p>
              </div>
              <div className="w-12 h-12 bg-red-100 rounded-lg flex items-center justify-center">
                <Clock className="h-6 w-6 text-red-500" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Recent Activities */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Recent Enrollments</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {recentStudents.length > 0 ? (
              recentStudents.map((student) => (
                <div key={student.id} className="flex items-center space-x-3">
                  <div className="w-10 h-10 bg-primary/10 rounded-full flex items-center justify-center">
                    <Users className="h-5 w-5 text-primary" />
                  </div>
                  <div className="flex-1">
                    <p className="font-medium">{student.firstName} {student.lastName}</p>
                    <p className="text-sm text-muted-foreground">Student ID: {student.studentId}</p>
                  </div>
                  <span className="text-xs text-muted-foreground">
                    {new Date(student.enrollmentDate).toLocaleDateString()}
                  </span>
                </div>
              ))
            ) : (
              <p className="text-muted-foreground text-center py-4">No students enrolled yet</p>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Payment Alerts</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {payments.filter(p => p.status === 'overdue').slice(0, 3).map((payment) => (
              <div key={payment.id} className="flex items-center space-x-3 p-3 bg-red-50 rounded-lg">
                <div className="w-8 h-8 bg-red-100 rounded-full flex items-center justify-center">
                  <TriangleAlert className="h-4 w-4 text-red-500" />
                </div>
                <div className="flex-1">
                  <p className="font-medium">{payment.student.firstName} {payment.student.lastName}</p>
                  <p className="text-sm text-red-600">Payment overdue - ${payment.amount}</p>
                </div>
              </div>
            ))}
            
            {payments.filter(p => p.status === 'pending').slice(0, 2).map((payment) => (
              <div key={payment.id} className="flex items-center space-x-3 p-3 bg-yellow-50 rounded-lg">
                <div className="w-8 h-8 bg-yellow-100 rounded-full flex items-center justify-center">
                  <Clock className="h-4 w-4 text-yellow-500" />
                </div>
                <div className="flex-1">
                  <p className="font-medium">{payment.student.firstName} {payment.student.lastName}</p>
                  <p className="text-sm text-yellow-600">Payment due - ${payment.amount}</p>
                </div>
              </div>
            ))}
            
            {payments.filter(p => p.status === 'paid').slice(0, 1).map((payment) => (
              <div key={payment.id} className="flex items-center space-x-3 p-3 bg-green-50 rounded-lg">
                <div className="w-8 h-8 bg-green-100 rounded-full flex items-center justify-center">
                  <DollarSign className="h-4 w-4 text-green-500" />
                </div>
                <div className="flex-1">
                  <p className="font-medium">{payment.student.firstName} {payment.student.lastName}</p>
                  <p className="text-sm text-green-600">Payment received - ${payment.amount}</p>
                </div>
              </div>
            ))}
            
            {payments.length === 0 && (
              <p className="text-muted-foreground text-center py-4">No payment records yet</p>
            )}
          </CardContent>
        </Card>
      </div>
    </AdminLayout>
  );
}
