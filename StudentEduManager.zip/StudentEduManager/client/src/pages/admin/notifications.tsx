import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { 
  Bell, 
  Send, 
  Users, 
  Filter,
  Plus,
  Calendar,
  AlertCircle,
  CheckCircle,
  Info,
  AlertTriangle
} from "lucide-react";
import AdminLayout from "@/components/admin-layout";
import NotificationPreferences from "@/components/notification-preferences";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

interface NotificationTemplate {
  id: number;
  name: string;
  title: string;
  message: string;
  type: 'info' | 'success' | 'warning' | 'error';
  category: string;
}

export default function AdminNotifications() {
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
  const [isPreferencesOpen, setIsPreferencesOpen] = useState(false);
  const [selectedRecipients, setSelectedRecipients] = useState<string>('all');
  const [notificationTitle, setNotificationTitle] = useState('');
  const [notificationMessage, setNotificationMessage] = useState('');
  const [notificationType, setNotificationType] = useState<string>('info');
  const [notificationCategory, setNotificationCategory] = useState<string>('announcement');
  const { toast } = useToast();

  // Mock notification templates
  const templates: NotificationTemplate[] = [
    {
      id: 1,
      name: "Payment Reminder",
      title: "Payment Due Reminder",
      message: "Your monthly tuition payment is due soon. Please make payment to avoid late fees.",
      type: 'warning',
      category: 'payment'
    },
    {
      id: 2,
      name: "Welcome Message",
      title: "Welcome to TechNCode!",
      message: "Welcome to our learning platform. We're excited to have you join our community.",
      type: 'success',
      category: 'system'
    },
    {
      id: 3,
      name: "Attendance Alert",
      title: "Attendance Warning",
      message: "Your attendance has fallen below the required threshold. Please contact your instructor.",
      type: 'error',
      category: 'attendance'
    }
  ];

  // Mock recent notifications
  const recentNotifications = [
    {
      id: 1,
      title: "System Maintenance Notice",
      recipients: 45,
      sentAt: "2025-01-20 14:30",
      type: 'info' as const,
      status: 'sent'
    },
    {
      id: 2,
      title: "Payment Deadline Reminder",
      recipients: 12,
      sentAt: "2025-01-20 10:15",
      type: 'warning' as const,
      status: 'sent'
    },
    {
      id: 3,
      title: "New Course Materials Available",
      recipients: 28,
      sentAt: "2025-01-19 16:45",
      type: 'success' as const,
      status: 'sent'
    }
  ];

  const sendNotificationMutation = useMutation({
    mutationFn: async (notificationData: any) => {
      // In real app: await apiRequest('POST', '/api/notifications/send', notificationData);
      console.log('Sending notification:', notificationData);
      return notificationData;
    },
    onSuccess: () => {
      toast({
        title: "Success",
        description: "Notification sent successfully",
      });
      setIsCreateModalOpen(false);
      resetForm();
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to send notification",
        variant: "destructive",
      });
    },
  });

  const resetForm = () => {
    setNotificationTitle('');
    setNotificationMessage('');
    setNotificationType('info');
    setNotificationCategory('announcement');
    setSelectedRecipients('all');
  };

  const handleSendNotification = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!notificationTitle || !notificationMessage) {
      toast({
        title: "Error",
        description: "Please fill in title and message",
        variant: "destructive",
      });
      return;
    }

    sendNotificationMutation.mutate({
      title: notificationTitle,
      message: notificationMessage,
      type: notificationType,
      category: notificationCategory,
      recipients: selectedRecipients,
    });
  };

  const useTemplate = (template: NotificationTemplate) => {
    setNotificationTitle(template.title);
    setNotificationMessage(template.message);
    setNotificationType(template.type);
    setNotificationCategory(template.category);
    setIsCreateModalOpen(true);
  };

  const getNotificationIcon = (type: string) => {
    switch (type) {
      case 'success':
        return <CheckCircle className="h-4 w-4 text-green-600" />;
      case 'warning':
        return <AlertTriangle className="h-4 w-4 text-yellow-600" />;
      case 'error':
        return <AlertCircle className="h-4 w-4 text-red-600" />;
      default:
        return <Info className="h-4 w-4 text-blue-600" />;
    }
  };

  const getTypeColor = (type: string) => {
    switch (type) {
      case 'success':
        return 'bg-green-100 text-green-800';
      case 'warning':
        return 'bg-yellow-100 text-yellow-800';
      case 'error':
        return 'bg-red-100 text-red-800';
      default:
        return 'bg-blue-100 text-blue-800';
    }
  };

  return (
    <AdminLayout 
      title="Notifications" 
      description="Send and manage notifications to students"
    >
      <div className="space-y-6">
        {/* Quick Actions */}
        <div className="flex flex-wrap gap-4">
          <Button onClick={() => setIsCreateModalOpen(true)}>
            <Plus className="h-4 w-4 mr-2" />
            Create Notification
          </Button>
          <Button variant="outline" onClick={() => setIsPreferencesOpen(true)}>
            <Bell className="h-4 w-4 mr-2" />
            Notification Settings
          </Button>
        </div>

        <Tabs defaultValue="send" className="space-y-6">
          <TabsList>
            <TabsTrigger value="send">Send Notification</TabsTrigger>
            <TabsTrigger value="templates">Templates</TabsTrigger>
            <TabsTrigger value="history">History</TabsTrigger>
            <TabsTrigger value="analytics">Analytics</TabsTrigger>
          </TabsList>

          {/* Send Notification Tab */}
          <TabsContent value="send" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Quick Send</CardTitle>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleSendNotification} className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="recipients">Recipients</Label>
                      <Select value={selectedRecipients} onValueChange={setSelectedRecipients}>
                        <SelectTrigger>
                          <SelectValue placeholder="Select recipients" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="all">All Students</SelectItem>
                          <SelectItem value="active">Active Students Only</SelectItem>
                          <SelectItem value="course-specific">Specific Course</SelectItem>
                          <SelectItem value="custom">Custom Selection</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="type">Type</Label>
                      <Select value={notificationType} onValueChange={setNotificationType}>
                        <SelectTrigger>
                          <SelectValue placeholder="Select type" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="info">Information</SelectItem>
                          <SelectItem value="success">Success</SelectItem>
                          <SelectItem value="warning">Warning</SelectItem>
                          <SelectItem value="error">Alert</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="title">Title</Label>
                    <Input
                      id="title"
                      value={notificationTitle}
                      onChange={(e) => setNotificationTitle(e.target.value)}
                      placeholder="Enter notification title"
                      required
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="message">Message</Label>
                    <Textarea
                      id="message"
                      value={notificationMessage}
                      onChange={(e) => setNotificationMessage(e.target.value)}
                      placeholder="Enter notification message"
                      rows={4}
                      required
                    />
                  </div>

                  <div className="flex space-x-2">
                    <Button type="submit" disabled={sendNotificationMutation.isPending}>
                      <Send className="h-4 w-4 mr-2" />
                      {sendNotificationMutation.isPending ? 'Sending...' : 'Send Notification'}
                    </Button>
                    <Button type="button" variant="outline" onClick={resetForm}>
                      Clear
                    </Button>
                  </div>
                </form>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Templates Tab */}
          <TabsContent value="templates" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {templates.map((template) => (
                <Card key={template.id} className="hover:shadow-md transition-shadow">
                  <CardContent className="p-4">
                    <div className="flex items-center justify-between mb-3">
                      <h4 className="font-medium">{template.name}</h4>
                      <Badge className={getTypeColor(template.type)}>
                        {template.type}
                      </Badge>
                    </div>
                    <p className="text-sm text-muted-foreground mb-2">{template.title}</p>
                    <p className="text-xs text-muted-foreground mb-4 line-clamp-2">
                      {template.message}
                    </p>
                    <Button 
                      size="sm" 
                      className="w-full"
                      onClick={() => useTemplate(template)}
                    >
                      Use Template
                    </Button>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          {/* History Tab */}
          <TabsContent value="history" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Recent Notifications</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {recentNotifications.map((notification) => (
                    <div key={notification.id} className="flex items-center justify-between p-4 border rounded-lg">
                      <div className="flex items-center space-x-3">
                        {getNotificationIcon(notification.type)}
                        <div>
                          <h4 className="font-medium">{notification.title}</h4>
                          <p className="text-sm text-muted-foreground">
                            Sent to {notification.recipients} recipients on {notification.sentAt}
                          </p>
                        </div>
                      </div>
                      <Badge className={getTypeColor(notification.type)}>
                        {notification.status}
                      </Badge>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Analytics Tab */}
          <TabsContent value="analytics" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm text-muted-foreground">Total Sent</p>
                      <p className="text-2xl font-bold">1,247</p>
                    </div>
                    <Send className="h-8 w-8 text-blue-600" />
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm text-muted-foreground">Read Rate</p>
                      <p className="text-2xl font-bold">87%</p>
                    </div>
                    <CheckCircle className="h-8 w-8 text-green-600" />
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm text-muted-foreground">This Month</p>
                      <p className="text-2xl font-bold">89</p>
                    </div>
                    <Calendar className="h-8 w-8 text-purple-600" />
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </div>

      {/* Notification Preferences Modal */}
      <Dialog open={isPreferencesOpen} onOpenChange={setIsPreferencesOpen}>
        <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Notification Settings</DialogTitle>
          </DialogHeader>
          <NotificationPreferences onClose={() => setIsPreferencesOpen(false)} />
        </DialogContent>
      </Dialog>
    </AdminLayout>
  );
}