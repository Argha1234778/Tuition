import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { CalendarCheck, Users, UserX, TrendingUp } from "lucide-react";
import AdminLayout from "@/components/admin-layout";
import type { Course, AttendanceWithDetails, EnrollmentWithDetails } from "@shared/schema";

export default function AdminAttendance() {
  const [selectedCourse, setSelectedCourse] = useState("");
  const [selectedDate, setSelectedDate] = useState(new Date().toISOString().split('T')[0]);

  const { data: courses = [] } = useQuery<Course[]>({
    queryKey: ['/api/courses'],
  });

  const { data: attendance = [] } = useQuery<AttendanceWithDetails[]>({
    queryKey: ['/api/attendance'],
  });

  const { data: enrollments = [] } = useQuery<EnrollmentWithDetails[]>({
    queryKey: ['/api/enrollments'],
  });

  const activeCourses = courses.filter(course => course.status === 'active');
  
  // Filter attendance for today and selected course
  const todayAttendance = attendance.filter(record => 
    record.date === selectedDate && 
    (!selectedCourse || record.courseId === parseInt(selectedCourse))
  );

  const presentCount = todayAttendance.filter(record => record.status === 'present').length;
  const absentCount = todayAttendance.filter(record => record.status === 'absent').length;
  const totalStudents = presentCount + absentCount;
  const attendanceRate = totalStudents > 0 ? Math.round((presentCount / totalStudents) * 100) : 0;

  // Get overall attendance statistics
  const getAttendanceStats = () => {
    const thisWeek = attendance.filter(record => {
      const recordDate = new Date(record.date);
      const today = new Date();
      const weekStart = new Date(today.setDate(today.getDate() - today.getDay()));
      return recordDate >= weekStart;
    });

    const thisMonth = attendance.filter(record => {
      const recordDate = new Date(record.date);
      const today = new Date();
      return recordDate.getMonth() === today.getMonth() && 
             recordDate.getFullYear() === today.getFullYear();
    });

    const weeklyPresent = thisWeek.filter(r => r.status === 'present').length;
    const weeklyTotal = thisWeek.length;
    const monthlyPresent = thisMonth.filter(r => r.status === 'present').length;
    const monthlyTotal = thisMonth.length;

    return {
      weeklyRate: weeklyTotal > 0 ? Math.round((weeklyPresent / weeklyTotal) * 100) : 0,
      monthlyRate: monthlyTotal > 0 ? Math.round((monthlyPresent / monthlyTotal) * 100) : 0,
    };
  };

  const stats = getAttendanceStats();
  const selectedCourseObj = courses.find(c => c.id === parseInt(selectedCourse));

  return (
    <AdminLayout title="Attendance Management" description="Track and manage student attendance">
      <div className="space-y-6">
        {/* Attendance Filters */}
        <Card>
          <CardContent className="p-4">
            <div className="flex flex-col md:flex-row gap-4">
              <Select value={selectedCourse} onValueChange={setSelectedCourse}>
                <SelectTrigger className="w-full md:w-[200px]">
                  <SelectValue placeholder="Select Course" />
                </SelectTrigger>
                <SelectContent>
                  {activeCourses.map((course) => (
                    <SelectItem key={course.id} value={course.id.toString()}>
                      {course.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <Input
                type="date"
                value={selectedDate}
                onChange={(e) => setSelectedDate(e.target.value)}
                className="w-full md:w-[200px]"
              />
              <Button className="w-full md:w-auto">
                Mark Attendance
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Attendance Overview */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <Card>
            <CardHeader>
              <CardTitle>
                Today's Attendance
                {selectedCourseObj && (
                  <span className="text-base font-normal text-muted-foreground ml-2">
                    - {selectedCourseObj.name}
                  </span>
                )}
              </CardTitle>
              <p className="text-sm text-muted-foreground">
                {new Date(selectedDate).toLocaleDateString()}
              </p>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-3 gap-4 mb-6">
                <div className="text-center">
                  <p className="text-2xl font-bold text-secondary">{presentCount}</p>
                  <p className="text-sm text-muted-foreground">Present</p>
                </div>
                <div className="text-center">
                  <p className="text-2xl font-bold text-destructive">{absentCount}</p>
                  <p className="text-sm text-muted-foreground">Absent</p>
                </div>
                <div className="text-center">
                  <p className="text-2xl font-bold text-accent">{attendanceRate}%</p>
                  <p className="text-sm text-muted-foreground">Rate</p>
                </div>
              </div>
              
              {todayAttendance.length > 0 ? (
                <div className="space-y-3">
                  {todayAttendance.slice(0, 5).map((record) => (
                    <div key={record.id} className="flex items-center justify-between">
                      <span className="text-foreground">
                        {record.student.firstName} {record.student.lastName}
                      </span>
                      <Badge 
                        className={record.status === 'present' 
                          ? "bg-green-100 text-green-800" 
                          : "bg-red-100 text-red-800"
                        }
                      >
                        {record.status.charAt(0).toUpperCase() + record.status.slice(1)}
                      </Badge>
                    </div>
                  ))}
                  {todayAttendance.length > 5 && (
                    <p className="text-sm text-muted-foreground text-center">
                      and {todayAttendance.length - 5} more students...
                    </p>
                  )}
                </div>
              ) : (
                <div className="text-center py-4">
                  <p className="text-muted-foreground">No attendance records for this date</p>
                </div>
              )}
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Attendance Trends</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-muted-foreground">This Week</span>
                    <span className="text-sm font-medium">{stats.weeklyRate}%</span>
                  </div>
                  <div className="w-full bg-muted rounded-full h-2">
                    <div 
                      className="bg-secondary h-2 rounded-full transition-all duration-300" 
                      style={{ width: `${stats.weeklyRate}%` }}
                    ></div>
                  </div>
                </div>
                
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-muted-foreground">This Month</span>
                    <span className="text-sm font-medium">{stats.monthlyRate}%</span>
                  </div>
                  <div className="w-full bg-muted rounded-full h-2">
                    <div 
                      className="bg-secondary h-2 rounded-full transition-all duration-300" 
                      style={{ width: `${stats.monthlyRate}%` }}
                    ></div>
                  </div>
                </div>
                
                <div className="pt-4 space-y-3">
                  <div className="flex items-center justify-between p-3 bg-muted rounded-lg">
                    <div className="flex items-center space-x-2">
                      <Users className="h-4 w-4 text-secondary" />
                      <span className="text-sm">Total Classes</span>
                    </div>
                    <span className="font-medium">{attendance.length}</span>
                  </div>
                  
                  <div className="flex items-center justify-between p-3 bg-muted rounded-lg">
                    <div className="flex items-center space-x-2">
                      <CalendarCheck className="h-4 w-4 text-primary" />
                      <span className="text-sm">Present Records</span>
                    </div>
                    <span className="font-medium">
                      {attendance.filter(r => r.status === 'present').length}
                    </span>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </AdminLayout>
  );
}
