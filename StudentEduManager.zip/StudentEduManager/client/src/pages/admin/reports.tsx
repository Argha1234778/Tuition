import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Users, DollarSign, CalendarCheck, Download, FileText, TrendingUp } from "lucide-react";
import AdminLayout from "@/components/admin-layout";
import { useToast } from "@/hooks/use-toast";
import { ReportGenerator } from "@/lib/report-generator";
import type { StudentWithUser, Course, PaymentWithDetails, AttendanceWithDetails } from "@shared/schema";

export default function AdminReports() {
  const { toast } = useToast();

  const { data: students = [] } = useQuery<StudentWithUser[]>({
    queryKey: ['/api/students'],
  });

  const { data: courses = [] } = useQuery<Course[]>({
    queryKey: ['/api/courses'],
  });

  const { data: payments = [] } = useQuery<PaymentWithDetails[]>({
    queryKey: ['/api/payments'],
  });

  const { data: attendance = [] } = useQuery<AttendanceWithDetails[]>({
    queryKey: ['/api/attendance'],
  });

  const handleDownloadReport = (reportType: string, downloadFn: () => void) => {
    try {
      downloadFn();
      toast({
        title: "Report Downloaded",
        description: `${reportType} report has been downloaded successfully.`,
      });
    } catch (error) {
      toast({
        title: "Download Error",
        description: `Failed to download ${reportType} report.`,
        variant: "destructive",
      });
    }
  };

  const reportData = { students, courses, payments, attendance };

  const downloadStudentReport = () => ReportGenerator.generateStudentReport(reportData);
  const downloadFinancialReport = () => ReportGenerator.generateFinancialReport(reportData);
  const downloadAttendanceReport = () => ReportGenerator.generateAttendanceReport(reportData);
  const downloadPerformanceReport = () => ReportGenerator.generatePerformanceReport(reportData);
  const downloadCustomReport = () => ReportGenerator.generateCustomReport(reportData);
  const downloadMonthlySummary = () => ReportGenerator.generateMonthlySummary(reportData);

  // Calculate some basic statistics
  const activeStudents = students.filter(s => s.status === 'active').length;
  const totalRevenue = payments.filter(p => p.status === 'paid').reduce((sum, p) => sum + Number(p.amount), 0);
  const overallAttendanceRate = attendance.length > 0 
    ? Math.round((attendance.filter(a => a.status === 'present').length / attendance.length) * 100)
    : 0;

  return (
    <AdminLayout title="Reports & Analytics" description="Generate comprehensive reports and insights">
      <div className="space-y-6">
        {/* Quick Stats */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Active Students</p>
                  <p className="text-2xl font-bold">{activeStudents}</p>
                </div>
                <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center">
                  <Users className="h-6 w-6 text-primary" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Total Revenue</p>
                  <p className="text-2xl font-bold">${totalRevenue.toLocaleString()}</p>
                </div>
                <div className="w-12 h-12 bg-secondary/10 rounded-lg flex items-center justify-center">
                  <DollarSign className="h-6 w-6 text-secondary" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Attendance Rate</p>
                  <p className="text-2xl font-bold">{overallAttendanceRate}%</p>
                </div>
                <div className="w-12 h-12 bg-accent/10 rounded-lg flex items-center justify-center">
                  <CalendarCheck className="h-6 w-6 text-accent" />
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Report Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          <Card className="card-hover">
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-4">
                <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center">
                  <Users className="h-6 w-6 text-primary" />
                </div>
                <Button 
                  variant="ghost" 
                  size="sm"
                  onClick={() => handleDownloadReport("Student", downloadStudentReport)}
                >
                  <Download className="h-4 w-4" />
                </Button>
              </div>
              <h3 className="text-lg font-semibold mb-2">Student Report</h3>
              <p className="text-muted-foreground text-sm mb-4">
                Comprehensive student enrollment and performance data including demographics, course enrollment, and academic progress.
              </p>
              <Button 
                className="w-full" 
                onClick={() => handleDownloadReport("Student", downloadStudentReport)}
              >
                <FileText className="h-4 w-4 mr-2" />
                Generate Report
              </Button>
            </CardContent>
          </Card>

          <Card className="card-hover">
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-4">
                <div className="w-12 h-12 bg-secondary/10 rounded-lg flex items-center justify-center">
                  <DollarSign className="h-6 w-6 text-secondary" />
                </div>
                <Button 
                  variant="ghost" 
                  size="sm"
                  onClick={() => handleDownloadReport("Financial", downloadFinancialReport)}
                >
                  <Download className="h-4 w-4" />
                </Button>
              </div>
              <h3 className="text-lg font-semibold mb-2">Financial Report</h3>
              <p className="text-muted-foreground text-sm mb-4">
                Revenue, payments, and financial analytics including payment trends, outstanding amounts, and collection rates.
              </p>
              <Button 
                className="w-full bg-secondary hover:bg-secondary/90 text-white" 
                onClick={() => handleDownloadReport("Financial", downloadFinancialReport)}
              >
                <FileText className="h-4 w-4 mr-2" />
                Generate Report
              </Button>
            </CardContent>
          </Card>

          <Card className="card-hover">
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-4">
                <div className="w-12 h-12 bg-accent/10 rounded-lg flex items-center justify-center">
                  <CalendarCheck className="h-6 w-6 text-accent" />
                </div>
                <Button variant="ghost" size="sm">
                  <Download className="h-4 w-4" />
                </Button>
              </div>
              <h3 className="text-lg font-semibold mb-2">Attendance Report</h3>
              <p className="text-muted-foreground text-sm mb-4">
                Detailed attendance tracking and patterns including course-wise attendance, trends, and student performance metrics.
              </p>
              <Button 
                className="w-full bg-accent hover:bg-accent/90 text-white" 
                onClick={() => handleDownloadReport("Attendance", downloadAttendanceReport)}
              >
                <FileText className="h-4 w-4 mr-2" />
                Generate Report
              </Button>
            </CardContent>
          </Card>

          <Card className="card-hover">
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-4">
                <div className="w-12 h-12 bg-orange-100 rounded-lg flex items-center justify-center">
                  <TrendingUp className="h-6 w-6 text-orange-600" />
                </div>
                <Button variant="ghost" size="sm">
                  <Download className="h-4 w-4" />
                </Button>
              </div>
              <h3 className="text-lg font-semibold mb-2">Performance Report</h3>
              <p className="text-muted-foreground text-sm mb-4">
                Academic performance analysis including grades, completion rates, and course effectiveness metrics.
              </p>
              <Button 
                className="w-full" 
                variant="outline"
                onClick={() => handleDownloadReport("Performance", downloadPerformanceReport)}
              >
                <FileText className="h-4 w-4 mr-2" />
                Generate Report
              </Button>
            </CardContent>
          </Card>

          <Card className="card-hover">
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-4">
                <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center">
                  <FileText className="h-6 w-6 text-purple-600" />
                </div>
                <Button variant="ghost" size="sm">
                  <Download className="h-4 w-4" />
                </Button>
              </div>
              <h3 className="text-lg font-semibold mb-2">Custom Report</h3>
              <p className="text-muted-foreground text-sm mb-4">
                Generate custom reports with specific date ranges, filters, and data points tailored to your needs.
              </p>
              <Button 
                className="w-full" 
                variant="outline"
                onClick={() => handleDownloadReport("Custom", downloadCustomReport)}
              >
                <FileText className="h-4 w-4 mr-2" />
                Configure Report
              </Button>
            </CardContent>
          </Card>

          <Card className="card-hover">
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-4">
                <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                  <TrendingUp className="h-6 w-6 text-blue-600" />
                </div>
                <Button variant="ghost" size="sm">
                  <Download className="h-4 w-4" />
                </Button>
              </div>
              <h3 className="text-lg font-semibold mb-2">Monthly Summary</h3>
              <p className="text-muted-foreground text-sm mb-4">
                Monthly business summary including key metrics, trends, and insights for management review.
              </p>
              <Button 
                className="w-full" 
                variant="outline"
                onClick={() => handleDownloadReport("Monthly Summary", downloadMonthlySummary)}
              >
                <FileText className="h-4 w-4 mr-2" />
                Generate Report
              </Button>
            </CardContent>
          </Card>
        </div>

        {/* Recent Reports */}
        <Card>
          <CardHeader>
            <CardTitle>Recent Reports</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              <div className="flex items-center justify-between p-3 border border-border rounded-lg">
                <div className="flex items-center space-x-3">
                  <div className="w-8 h-8 bg-primary/10 rounded-lg flex items-center justify-center">
                    <FileText className="h-4 w-4 text-primary" />
                  </div>
                  <div>
                    <p className="font-medium">Student Enrollment Report</p>
                    <p className="text-sm text-muted-foreground">Generated 2 hours ago</p>
                  </div>
                </div>
                <Button variant="ghost" size="sm">
                  <Download className="h-4 w-4" />
                </Button>
              </div>

              <div className="flex items-center justify-between p-3 border border-border rounded-lg">
                <div className="flex items-center space-x-3">
                  <div className="w-8 h-8 bg-secondary/10 rounded-lg flex items-center justify-center">
                    <DollarSign className="h-4 w-4 text-secondary" />
                  </div>
                  <div>
                    <p className="font-medium">Monthly Financial Summary</p>
                    <p className="text-sm text-muted-foreground">Generated yesterday</p>
                  </div>
                </div>
                <Button variant="ghost" size="sm">
                  <Download className="h-4 w-4" />
                </Button>
              </div>

              <div className="flex items-center justify-between p-3 border border-border rounded-lg">
                <div className="flex items-center space-x-3">
                  <div className="w-8 h-8 bg-accent/10 rounded-lg flex items-center justify-center">
                    <CalendarCheck className="h-4 w-4 text-accent" />
                  </div>
                  <div>
                    <p className="font-medium">Weekly Attendance Report</p>
                    <p className="text-sm text-muted-foreground">Generated 3 days ago</p>
                  </div>
                </div>
                <Button variant="ghost" size="sm">
                  <Download className="h-4 w-4" />
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </AdminLayout>
  );
}
