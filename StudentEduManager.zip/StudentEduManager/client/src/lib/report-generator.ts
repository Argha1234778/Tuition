export interface ReportData {
  students: any[];
  courses: any[];
  payments: any[];
  attendance: any[];
}

export class ReportGenerator {
  static generateCSV(data: any[], filename: string): void {
    if (!data.length) {
      console.warn('No data to export');
      return;
    }

    const headers = Object.keys(data[0]);
    const csvContent = [
      headers.join(','),
      ...data.map(row => 
        headers.map(header => {
          const value = row[header];
          if (value === null || value === undefined) return '';
          if (typeof value === 'string' && value.includes(',')) {
            return `"${value.replace(/"/g, '""')}"`;
          }
          return String(value);
        }).join(',')
      )
    ].join('\n');

    this.downloadFile(csvContent, filename, 'text/csv');
  }

  static generateStudentReport(reportData: ReportData): void {
    const studentData = reportData.students.map(student => ({
      'Student ID': student.studentId,
      'Name': `${student.firstName} ${student.lastName}`,
      'Email': student.email,
      'Phone': student.phone || 'N/A',
      'Status': student.status,
      'Enrollment Date': new Date(student.enrollmentDate).toLocaleDateString(),
    }));

    this.generateCSV(studentData, 'student-report.csv');
  }

  static generateFinancialReport(reportData: ReportData): void {
    const totalRevenue = reportData.payments
      .filter(p => p.status === 'paid')
      .reduce((sum, p) => sum + Number(p.amount), 0);

    const pendingAmount = reportData.payments
      .filter(p => p.status === 'pending')
      .reduce((sum, p) => sum + Number(p.amount), 0);

    const financialData = [
      { 'Metric': 'Total Revenue', 'Amount': totalRevenue },
      { 'Metric': 'Pending Payments', 'Amount': pendingAmount },
      { 'Metric': 'Total Students', 'Amount': reportData.students.length },
      { 'Metric': 'Active Students', 'Amount': reportData.students.filter(s => s.status === 'active').length },
    ];

    this.generateCSV(financialData, 'financial-report.csv');
  }

  static generateAttendanceReport(reportData: ReportData): void {
    const attendanceData = reportData.attendance.map(record => ({
      'Date': new Date(record.date).toLocaleDateString(),
      'Student': record.student ? `${record.student.firstName} ${record.student.lastName}` : 'N/A',
      'Course': record.course ? record.course.name : 'N/A',
      'Status': record.status,
    }));

    this.generateCSV(attendanceData, 'attendance-report.csv');
  }

  static generatePerformanceReport(reportData: ReportData): void {
    // This would require enrollment/grade data - simplified for now
    const performanceData = reportData.students.map(student => ({
      'Student ID': student.studentId,
      'Name': `${student.firstName} ${student.lastName}`,
      'Status': student.status,
      'Courses Enrolled': 'N/A', // Would need enrollment data
      'Average Grade': 'N/A', // Would need grade data
    }));

    this.generateCSV(performanceData, 'performance-report.csv');
  }

  static generateCustomReport(reportData: ReportData): void {
    const customData = reportData.students.map(student => ({
      'Student ID': student.studentId,
      'Name': `${student.firstName} ${student.lastName}`,
      'Email': student.email,
      'Status': student.status,
      'Enrollment Date': new Date(student.enrollmentDate).toLocaleDateString(),
      'Total Courses': reportData.courses.length,
    }));

    this.generateCSV(customData, 'custom-report.csv');
  }

  static generateMonthlySummary(reportData: ReportData): void {
    const currentMonth = new Date().getMonth();
    const currentYear = new Date().getFullYear();
    
    const monthlyData = [
      {
        'Month': new Date(currentYear, currentMonth).toLocaleDateString('en-US', { month: 'long', year: 'numeric' }),
        'New Students': reportData.students.filter(s => {
          const enrollDate = new Date(s.enrollmentDate);
          return enrollDate.getMonth() === currentMonth && enrollDate.getFullYear() === currentYear;
        }).length,
        'Total Revenue': reportData.payments
          .filter(p => {
            const payDate = new Date(p.paymentDate);
            return p.status === 'paid' && payDate.getMonth() === currentMonth && payDate.getFullYear() === currentYear;
          })
          .reduce((sum, p) => sum + Number(p.amount), 0),
        'Active Courses': reportData.courses.filter(c => c.status === 'active').length,
      }
    ];

    this.generateCSV(monthlyData, 'monthly-summary.csv');
  }

  private static downloadFile(content: string, filename: string, mimeType: string): void {
    const blob = new Blob([content], { type: mimeType });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = filename;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  }
}