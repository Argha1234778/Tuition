import { apiRequest } from "./queryClient";

export interface User {
  id: number;
  username: string;
  role: 'admin' | 'student';
}

export interface Student {
  id: number;
  studentId: string;
  firstName: string;
  lastName: string;
  email: string;
  phone?: string;
  address?: string;
  enrollmentDate: string;
  status: 'active' | 'inactive' | 'graduated';
}

export interface AuthResponse {
  user: User;
  student?: Student;
}

export class AuthService {
  static async login(username: string, password: string): Promise<AuthResponse> {
    const response = await apiRequest('POST', '/api/auth/login', {
      username,
      password,
    });
    return response.json();
  }

  static async logout(): Promise<void> {
    await apiRequest('POST', '/api/auth/logout');
  }

  static async getCurrentUser(): Promise<AuthResponse> {
    const response = await apiRequest('GET', '/api/auth/me');
    return response.json();
  }
}
