import { useState } from "react";
import { Link, useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import { 
  GraduationCap, 
  BarChart3, 
  Users, 
  BookOpen, 
  CreditCard, 
  CalendarCheck, 
  FileText,
  Bell,
  LogOut,
  Menu,
  User
} from "lucide-react";
import { AuthService } from "@/lib/auth";
import NotificationCenter from "./notification-center";
import { queryClient } from "@/lib/queryClient";

interface AdminLayoutProps {
  children: React.ReactNode;
  title: string;
  description?: string;
}

const navigation = [
  { name: "Dashboard", href: "/admin/dashboard", icon: BarChart3 },
  { name: "Students", href: "/admin/students", icon: Users },
  { name: "Courses", href: "/admin/courses", icon: BookOpen },
  { name: "Payments", href: "/admin/payments", icon: CreditCard },
  { name: "Attendance", href: "/admin/attendance", icon: CalendarCheck },
  { name: "Reports", href: "/admin/reports", icon: FileText },
  { name: "Notifications", href: "/admin/notifications", icon: Bell },
];

export default function AdminLayout({ children, title, description }: AdminLayoutProps) {
  const [location, setLocation] = useLocation();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  const handleLogout = async () => {
    await AuthService.logout();
    queryClient.invalidateQueries({ queryKey: ['/api/auth/me'] });
    setLocation('/');
  };

  const Sidebar = () => (
    <nav className="space-y-2 p-4">
      {navigation.map((item) => {
        const isActive = location === item.href || location.startsWith(item.href);
        const Icon = item.icon;
        
        return (
          <Link key={item.name} href={item.href}>
            <Button
              variant={isActive ? "default" : "ghost"}
              className="w-full justify-start sidebar-nav-item"
              onClick={() => setIsMobileMenuOpen(false)}
            >
              <Icon className="mr-3 h-4 w-4" />
              {item.name}
            </Button>
          </Link>
        );
      })}
    </nav>
  );

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="bg-card shadow-sm border-b border-border fixed w-full top-0 z-40">
        <div className="flex items-center justify-between px-6 py-4">
          <div className="flex items-center space-x-4">
            <Sheet open={isMobileMenuOpen} onOpenChange={setIsMobileMenuOpen}>
              <SheetTrigger asChild>
                <Button variant="ghost" size="sm" className="md:hidden">
                  <Menu className="h-5 w-5" />
                </Button>
              </SheetTrigger>
              <SheetContent side="left" className="w-64 p-0">
                <div className="flex items-center space-x-2 p-4 border-b border-border">
                  <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center">
                    <GraduationCap className="h-5 w-5 text-white" />
                  </div>
                  <span className="font-bold text-lg">TechNCode</span>
                </div>
                <Sidebar />
              </SheetContent>
            </Sheet>
            
            <div className="hidden md:flex items-center space-x-4">
              <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center">
                <GraduationCap className="h-5 w-5 text-white" />
              </div>
              <h1 className="text-xl font-bold text-foreground">TechNCode Admin</h1>
            </div>
          </div>
          
          <div className="flex items-center space-x-4">
            <NotificationCenter />
            
            <div className="flex items-center space-x-2">
              <div className="w-8 h-8 bg-primary rounded-full flex items-center justify-center">
                <User className="h-4 w-4 text-white" />
              </div>
              <span className="text-sm font-medium hidden sm:inline">Admin</span>
              <Button variant="ghost" size="sm" onClick={handleLogout}>
                <LogOut className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </div>
      </header>

      <div className="flex pt-16">
        {/* Desktop Sidebar */}
        <aside className="hidden md:block w-64 bg-card shadow-sm border-r border-border min-h-screen fixed">
          <Sidebar />
        </aside>

        {/* Main Content */}
        <main className="flex-1 md:ml-64 p-6 min-h-screen flex flex-col">
          <div className="mb-6">
            <h2 className="text-2xl font-bold text-foreground">{title}</h2>
            {description && <p className="text-muted-foreground">{description}</p>}
          </div>
          <div className="flex-1">{children}</div>
          <footer className="mt-8 pt-4 border-t border-border text-center text-sm text-muted-foreground">
            © 2025 TechNCode - Developed by Argha Sir
          </footer>
        </main>
      </div>
    </div>
  );
}
