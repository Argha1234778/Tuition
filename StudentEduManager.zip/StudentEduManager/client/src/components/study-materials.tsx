import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { 
  Download, 
  Upload, 
  FileText, 
  Video, 
  Image, 
  File, 
  Plus, 
  Eye,
  Calendar,
  Clock
} from "lucide-react";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

interface StudyMaterial {
  id: number;
  title: string;
  description: string;
  type: 'document' | 'video' | 'image' | 'other';
  url: string;
  courseId: number;
  courseName: string;
  uploadDate: string;
  size: string;
}

interface StudyMaterialsProps {
  isAdmin?: boolean;
  courseId?: number;
}

export default function StudyMaterials({ isAdmin = false, courseId }: StudyMaterialsProps) {
  const [isUploadModalOpen, setIsUploadModalOpen] = useState(false);
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const { toast } = useToast();

  // Mock data for demonstration - in real app this would come from API
  const studyMaterials: StudyMaterial[] = [
    {
      id: 1,
      title: "Introduction to Programming",
      description: "Basic concepts and fundamentals of programming",
      type: 'document',
      url: '#',
      courseId: 1,
      courseName: "Computer Science Basics",
      uploadDate: "2025-01-15",
      size: "2.4 MB"
    },
    {
      id: 2,
      title: "Database Design Tutorial",
      description: "Complete guide to database design principles",
      type: 'video',
      url: '#',
      courseId: 1,
      courseName: "Computer Science Basics",
      uploadDate: "2025-01-10",
      size: "45.2 MB"
    },
    {
      id: 3,
      title: "Algorithm Flowchart",
      description: "Visual representation of common algorithms",
      type: 'image',
      url: '#',
      courseId: 1,
      courseName: "Computer Science Basics",
      uploadDate: "2025-01-08",
      size: "1.8 MB"
    }
  ];

  const filteredMaterials = courseId 
    ? studyMaterials.filter(m => m.courseId === courseId)
    : studyMaterials;

  const handleFileSelect = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      setSelectedFile(file);
    }
  };

  const handleUpload = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!selectedFile || !title) {
      toast({
        title: "Error",
        description: "Please select a file and enter a title",
        variant: "destructive",
      });
      return;
    }

    // In a real app, this would upload to a server
    toast({
      title: "Success",
      description: "Study material uploaded successfully",
    });

    // Reset form
    setTitle("");
    setDescription("");
    setSelectedFile(null);
    setIsUploadModalOpen(false);
  };

  const handleDownload = (material: StudyMaterial) => {
    // In a real app, this would download the actual file
    const dummyContent = `Study Material: ${material.title}\n\nDescription: ${material.description}\n\nCourse: ${material.courseName}\n\nUpload Date: ${new Date(material.uploadDate).toLocaleDateString()}`;
    
    const blob = new Blob([dummyContent], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `${material.title.replace(/\s+/g, '_')}.txt`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);

    toast({
      title: "Downloaded",
      description: `${material.title} has been downloaded`,
    });
  };

  const getFileIcon = (type: string) => {
    switch (type) {
      case 'document':
        return <FileText className="h-5 w-5 text-blue-600" />;
      case 'video':
        return <Video className="h-5 w-5 text-red-600" />;
      case 'image':
        return <Image className="h-5 w-5 text-green-600" />;
      default:
        return <File className="h-5 w-5 text-gray-600" />;
    }
  };

  const getFileTypeColor = (type: string) => {
    switch (type) {
      case 'document':
        return 'bg-blue-100 text-blue-800';
      case 'video':
        return 'bg-red-100 text-red-800';
      case 'image':
        return 'bg-green-100 text-green-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h3 className="text-lg font-semibold">Study Materials</h3>
          <p className="text-sm text-muted-foreground">
            {isAdmin ? "Manage course materials" : "Access your course materials"}
          </p>
        </div>
        {isAdmin && (
          <Button onClick={() => setIsUploadModalOpen(true)}>
            <Plus className="h-4 w-4 mr-2" />
            Upload Material
          </Button>
        )}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredMaterials.map((material) => (
          <Card key={material.id} className="hover:shadow-md transition-shadow">
            <CardContent className="p-4">
              <div className="flex items-start justify-between mb-3">
                <div className="flex items-center space-x-2">
                  {getFileIcon(material.type)}
                  <Badge className={`text-xs ${getFileTypeColor(material.type)}`}>
                    {material.type}
                  </Badge>
                </div>
                <span className="text-xs text-muted-foreground">{material.size}</span>
              </div>
              
              <h4 className="font-medium mb-2 line-clamp-2">{material.title}</h4>
              <p className="text-sm text-muted-foreground mb-3 line-clamp-2">
                {material.description}
              </p>
              
              <div className="flex items-center justify-between text-xs text-muted-foreground mb-3">
                <div className="flex items-center space-x-1">
                  <Calendar className="h-3 w-3" />
                  <span>{new Date(material.uploadDate).toLocaleDateString()}</span>
                </div>
              </div>
              
              <div className="flex space-x-2">
                <Button 
                  size="sm" 
                  variant="outline" 
                  className="flex-1"
                  onClick={() => handleDownload(material)}
                >
                  <Download className="h-3 w-3 mr-1" />
                  Download
                </Button>
                <Button size="sm" variant="ghost">
                  <Eye className="h-3 w-3" />
                </Button>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {filteredMaterials.length === 0 && (
        <Card>
          <CardContent className="p-8 text-center">
            <FileText className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
            <h4 className="text-lg font-medium mb-2">No study materials</h4>
            <p className="text-muted-foreground">
              {isAdmin 
                ? "Upload your first study material to get started" 
                : "No materials have been uploaded for this course yet"
              }
            </p>
          </CardContent>
        </Card>
      )}

      {/* Upload Modal */}
      <Dialog open={isUploadModalOpen} onOpenChange={setIsUploadModalOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Upload Study Material</DialogTitle>
          </DialogHeader>
          
          <form onSubmit={handleUpload} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="title">Title *</Label>
              <Input
                id="title"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="Enter material title"
                required
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="description">Description</Label>
              <Textarea
                id="description"
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder="Brief description of the material"
                rows={3}
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="file">File *</Label>
              <Input
                id="file"
                type="file"
                onChange={handleFileSelect}
                accept=".pdf,.doc,.docx,.ppt,.pptx,.mp4,.avi,.mov,.jpg,.jpeg,.png,.gif"
                required
              />
              {selectedFile && (
                <p className="text-sm text-muted-foreground">
                  Selected: {selectedFile.name} ({(selectedFile.size / 1024 / 1024).toFixed(2)} MB)
                </p>
              )}
            </div>
            
            <div className="flex space-x-2">
              <Button type="submit" className="flex-1">
                <Upload className="h-4 w-4 mr-2" />
                Upload
              </Button>
              <Button 
                type="button" 
                variant="outline" 
                onClick={() => setIsUploadModalOpen(false)}
              >
                Cancel
              </Button>
            </div>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
}