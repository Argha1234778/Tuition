import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Separator } from "@/components/ui/separator";
import { Badge } from "@/components/ui/badge";
import { 
  Bell, 
  Mail, 
  MessageSquare, 
  Smartphone,
  Clock,
  Volume,
  VolumeX,
  Settings
} from "lucide-react";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

interface NotificationPreferences {
  emailNotifications: boolean;
  pushNotifications: boolean;
  smsNotifications: boolean;
  paymentReminders: boolean;
  attendanceAlerts: boolean;
  gradeUpdates: boolean;
  courseAnnouncements: boolean;
  systemUpdates: boolean;
  quietHoursStart: string;
  quietHoursEnd: string;
  weekendNotifications: boolean;
}

interface NotificationPreferencesProps {
  onClose?: () => void;
}

export default function NotificationPreferences({ onClose }: NotificationPreferencesProps) {
  const { toast } = useToast();
  
  // Mock preferences for demonstration
  const [preferences, setPreferences] = useState<NotificationPreferences>({
    emailNotifications: true,
    pushNotifications: true,
    smsNotifications: false,
    paymentReminders: true,
    attendanceAlerts: true,
    gradeUpdates: true,
    courseAnnouncements: true,
    systemUpdates: true,
    quietHoursStart: '22:00',
    quietHoursEnd: '08:00',
    weekendNotifications: false,
  });

  const updatePreferencesMutation = useMutation({
    mutationFn: async (updatedPreferences: NotificationPreferences) => {
      // In real app: await apiRequest('PUT', '/api/notifications/preferences', updatedPreferences);
      console.log('Updating notification preferences:', updatedPreferences);
      return updatedPreferences;
    },
    onSuccess: () => {
      toast({
        title: "Success",
        description: "Notification preferences updated successfully",
      });
      // queryClient.invalidateQueries({ queryKey: ['/api/notifications/preferences'] });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to update notification preferences",
        variant: "destructive",
      });
    },
  });

  const handleToggle = (key: keyof NotificationPreferences, value: boolean) => {
    const updatedPreferences = { ...preferences, [key]: value };
    setPreferences(updatedPreferences);
    updatePreferencesMutation.mutate(updatedPreferences);
  };

  const handleTimeChange = (key: 'quietHoursStart' | 'quietHoursEnd', value: string) => {
    const updatedPreferences = { ...preferences, [key]: value };
    setPreferences(updatedPreferences);
    updatePreferencesMutation.mutate(updatedPreferences);
  };

  const testNotification = () => {
    toast({
      title: "Test Notification",
      description: "This is a test notification to check your settings",
    });
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h3 className="text-lg font-semibold flex items-center">
            <Settings className="h-5 w-5 mr-2" />
            Notification Preferences
          </h3>
          <p className="text-sm text-muted-foreground">
            Customize how and when you receive notifications
          </p>
        </div>
        <Button onClick={testNotification} variant="outline" size="sm">
          <Bell className="h-4 w-4 mr-2" />
          Test Notification
        </Button>
      </div>

      {/* Delivery Methods */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base">Delivery Methods</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <Mail className="h-4 w-4 text-muted-foreground" />
              <div>
                <Label htmlFor="email">Email Notifications</Label>
                <p className="text-xs text-muted-foreground">
                  Receive notifications via email
                </p>
              </div>
            </div>
            <Switch
              id="email"
              checked={preferences.emailNotifications}
              onCheckedChange={(value) => handleToggle('emailNotifications', value)}
            />
          </div>

          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <Bell className="h-4 w-4 text-muted-foreground" />
              <div>
                <Label htmlFor="push">Push Notifications</Label>
                <p className="text-xs text-muted-foreground">
                  Browser and app notifications
                </p>
              </div>
            </div>
            <Switch
              id="push"
              checked={preferences.pushNotifications}
              onCheckedChange={(value) => handleToggle('pushNotifications', value)}
            />
          </div>

          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <Smartphone className="h-4 w-4 text-muted-foreground" />
              <div>
                <Label htmlFor="sms">SMS Notifications</Label>
                <p className="text-xs text-muted-foreground">
                  Text messages for urgent notifications
                </p>
              </div>
              <Badge variant="outline" className="text-xs">Premium</Badge>
            </div>
            <Switch
              id="sms"
              checked={preferences.smsNotifications}
              onCheckedChange={(value) => handleToggle('smsNotifications', value)}
            />
          </div>
        </CardContent>
      </Card>

      {/* Notification Types */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base">Notification Types</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <Label htmlFor="payments">Payment Reminders</Label>
              <p className="text-xs text-muted-foreground">
                Due dates and payment confirmations
              </p>
            </div>
            <Switch
              id="payments"
              checked={preferences.paymentReminders}
              onCheckedChange={(value) => handleToggle('paymentReminders', value)}
            />
          </div>

          <div className="flex items-center justify-between">
            <div>
              <Label htmlFor="attendance">Attendance Alerts</Label>
              <p className="text-xs text-muted-foreground">
                Absence notifications and attendance updates
              </p>
            </div>
            <Switch
              id="attendance"
              checked={preferences.attendanceAlerts}
              onCheckedChange={(value) => handleToggle('attendanceAlerts', value)}
            />
          </div>

          <div className="flex items-center justify-between">
            <div>
              <Label htmlFor="grades">Grade Updates</Label>
              <p className="text-xs text-muted-foreground">
                New grades and performance reports
              </p>
            </div>
            <Switch
              id="grades"
              checked={preferences.gradeUpdates}
              onCheckedChange={(value) => handleToggle('gradeUpdates', value)}
            />
          </div>

          <div className="flex items-center justify-between">
            <div>
              <Label htmlFor="announcements">Course Announcements</Label>
              <p className="text-xs text-muted-foreground">
                Important course updates and materials
              </p>
            </div>
            <Switch
              id="announcements"
              checked={preferences.courseAnnouncements}
              onCheckedChange={(value) => handleToggle('courseAnnouncements', value)}
            />
          </div>

          <div className="flex items-center justify-between">
            <div>
              <Label htmlFor="system">System Updates</Label>
              <p className="text-xs text-muted-foreground">
                Maintenance and system announcements
              </p>
            </div>
            <Switch
              id="system"
              checked={preferences.systemUpdates}
              onCheckedChange={(value) => handleToggle('systemUpdates', value)}
            />
          </div>
        </CardContent>
      </Card>

      {/* Quiet Hours */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base flex items-center">
            {preferences.quietHoursStart && preferences.quietHoursEnd ? (
              <VolumeX className="h-4 w-4 mr-2" />
            ) : (
              <Volume className="h-4 w-4 mr-2" />
            )}
            Quiet Hours
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <p className="text-sm text-muted-foreground">
            Set hours when you don't want to receive notifications (except urgent ones)
          </p>
          
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="quiet-start">Start Time</Label>
              <Input
                id="quiet-start"
                type="time"
                value={preferences.quietHoursStart}
                onChange={(e) => handleTimeChange('quietHoursStart', e.target.value)}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="quiet-end">End Time</Label>
              <Input
                id="quiet-end"
                type="time"
                value={preferences.quietHoursEnd}
                onChange={(e) => handleTimeChange('quietHoursEnd', e.target.value)}
              />
            </div>
          </div>

          <div className="flex items-center justify-between">
            <div>
              <Label htmlFor="weekends">Weekend Notifications</Label>
              <p className="text-xs text-muted-foreground">
                Receive notifications on weekends
              </p>
            </div>
            <Switch
              id="weekends"
              checked={preferences.weekendNotifications}
              onCheckedChange={(value) => handleToggle('weekendNotifications', value)}
            />
          </div>
        </CardContent>
      </Card>

      {/* Smart Features */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base">Smart Features</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-3">
            <div className="flex items-center justify-between p-3 bg-blue-50 rounded-lg">
              <div>
                <Label className="font-medium">Smart Scheduling</Label>
                <p className="text-xs text-muted-foreground">
                  AI-powered notification timing based on your activity patterns
                </p>
              </div>
              <Badge variant="outline" className="text-blue-700 bg-blue-100">
                Coming Soon
              </Badge>
            </div>

            <div className="flex items-center justify-between p-3 bg-green-50 rounded-lg">
              <div>
                <Label className="font-medium">Priority Learning</Label>
                <p className="text-xs text-muted-foreground">
                  Automatically prioritize notifications based on your learning goals
                </p>
              </div>
              <Badge variant="outline" className="text-green-700 bg-green-100">
                Beta
              </Badge>
            </div>

            <div className="flex items-center justify-between p-3 bg-purple-50 rounded-lg">
              <div>
                <Label className="font-medium">Predictive Reminders</Label>
                <p className="text-xs text-muted-foreground">
                  Get proactive reminders before important deadlines
                </p>
              </div>
              <Badge variant="outline" className="text-purple-700 bg-purple-100">
                Active
              </Badge>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}