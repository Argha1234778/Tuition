import { useState } from "react";
import React from "react";
import { useMutation, useQuery } from "@tanstack/react-query";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Loader2 } from "lucide-react";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import type { Course } from "@shared/schema";

interface StudentModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  editStudent?: any;
}

export default function StudentModal({ open, onOpenChange, editStudent }: StudentModalProps) {
  const [firstName, setFirstName] = useState("");
  const [lastName, setLastName] = useState("");
  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");
  const [address, setAddress] = useState("");
  const [selectedCourse, setSelectedCourse] = useState("");
  
  // Populate form when editing
  React.useEffect(() => {
    if (editStudent) {
      setFirstName(editStudent.firstName || "");
      setLastName(editStudent.lastName || "");
      setEmail(editStudent.email || "");
      setPhone(editStudent.phone || "");
      setAddress(editStudent.address || "");
    } else {
      setFirstName("");
      setLastName("");
      setEmail("");
      setPhone("");
      setAddress("");
      setSelectedCourse("");
    }
  }, [editStudent, open]);
  const { toast } = useToast();

  const { data: courses = [] } = useQuery<Course[]>({
    queryKey: ['/api/courses'],
    enabled: open,
  });

  const createStudentMutation = useMutation({
    mutationFn: async (data: any) => {
      if (editStudent) {
        const response = await apiRequest('PUT', `/api/students/${editStudent.id}`, data);
        return response.json();
      } else {
        const response = await apiRequest('POST', '/api/students', data);
        return response.json();
      }
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ['/api/students'] });
      if (editStudent) {
        toast({
          title: "Student Updated Successfully",
          description: "Student information has been updated",
        });
      } else {
        toast({
          title: "Student Created Successfully", 
          description: `Login credentials: ${data.credentials.username} / ${data.credentials.password}`,
          duration: 10000,
        });
      }
      handleClose();
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || (editStudent ? "Failed to update student" : "Failed to create student"),
        variant: "destructive",
      });
    },
  });

  const createEnrollmentMutation = useMutation({
    mutationFn: async (data: any) => {
      const response = await apiRequest('POST', '/api/enrollments', data);
      return response.json();
    },
  });

  const handleClose = () => {
    setFirstName("");
    setLastName("");
    setEmail("");
    setPhone("");
    setAddress("");
    setSelectedCourse("");
    onOpenChange(false);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!firstName || !lastName || !email) {
      toast({
        title: "Error",
        description: "Please fill in all required fields",
        variant: "destructive",
      });
      return;
    }

    try {
      const studentData = await createStudentMutation.mutateAsync({
        firstName,
        lastName,
        email,
        phone: phone || undefined,
        address: address || undefined,
      });

      // Enroll in course if selected
      if (selectedCourse && studentData.student) {
        await createEnrollmentMutation.mutateAsync({
          studentId: studentData.student.id,
          courseId: parseInt(selectedCourse),
          enrollmentDate: new Date().toISOString().split('T')[0],
        });
        queryClient.invalidateQueries({ queryKey: ['/api/enrollments'] });
      }
    } catch (error) {
      // Error is handled by mutation onError
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>{editStudent ? "Edit Student" : "Add New Student"}</DialogTitle>

        </DialogHeader>
        
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="firstName">First Name *</Label>
              <Input
                id="firstName"
                value={firstName}
                onChange={(e) => setFirstName(e.target.value)}
                required
                disabled={createStudentMutation.isPending}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="lastName">Last Name *</Label>
              <Input
                id="lastName"
                value={lastName}
                onChange={(e) => setLastName(e.target.value)}
                required
                disabled={createStudentMutation.isPending}
              />
            </div>
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="email">Email *</Label>
            <Input
              id="email"
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
              disabled={createStudentMutation.isPending}
            />
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="phone">Phone</Label>
            <Input
              id="phone"
              type="tel"
              value={phone}
              onChange={(e) => setPhone(e.target.value)}
              disabled={createStudentMutation.isPending}
            />
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="address">Address</Label>
            <Textarea
              id="address"
              rows={2}
              value={address}
              onChange={(e) => setAddress(e.target.value)}
              disabled={createStudentMutation.isPending}
            />
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="course">Initial Course (Optional)</Label>
            <Select value={selectedCourse} onValueChange={setSelectedCourse}>
              <SelectTrigger>
                <SelectValue placeholder="Select a course" />
              </SelectTrigger>
              <SelectContent>
                {courses.filter(course => course.status === 'active').map((course) => (
                  <SelectItem key={course.id} value={course.id.toString()}>
                    {course.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          
          <div className="flex space-x-4 pt-4">
            <Button
              type="button"
              variant="outline"
              className="flex-1"
              onClick={handleClose}
              disabled={createStudentMutation.isPending}
            >
              Cancel
            </Button>
            <Button
              type="submit"
              className="flex-1"
              disabled={createStudentMutation.isPending}
            >
              {createStudentMutation.isPending ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Creating...
                </>
              ) : (
                "Add Student"
              )}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}
