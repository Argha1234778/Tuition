import { Switch, Route, useLocation } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { useQuery } from "@tanstack/react-query";
import { AuthService } from "./lib/auth";
import NotFound from "@/pages/not-found";
import LoginPage from "@/pages/login";

// Admin Pages
import AdminDashboard from "@/pages/admin/dashboard";
import AdminStudents from "@/pages/admin/students";
import AdminCourses from "@/pages/admin/courses";
import AdminPayments from "@/pages/admin/payments";
import AdminAttendance from "@/pages/admin/attendance";
import AdminReports from "@/pages/admin/reports";
import AdminNotifications from "@/pages/admin/notifications";

// Student Pages
import StudentDashboard from "@/pages/student/dashboard";
import StudentCourses from "@/pages/student/courses";
import StudentPayments from "@/pages/student/payments";
import StudentAttendance from "@/pages/student/attendance";
import StudentProgress from "@/pages/student/progress";
import StudentProfile from "@/pages/student/profile";
import StudentNotifications from "@/pages/student/notifications";

function Router() {
  const [location] = useLocation();
  
  const { data: auth, isLoading } = useQuery({
    queryKey: ['/api/auth/me'],
    queryFn: () => AuthService.getCurrentUser(),
    retry: false,
    staleTime: 5 * 60 * 1000, // 5 minutes
  });

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
      </div>
    );
  }

  if (!auth?.user) {
    return <LoginPage />;
  }

  return (
    <Switch>
      {auth.user.role === 'admin' && (
        <>
          <Route path="/" component={AdminDashboard} />
          <Route path="/admin" component={AdminDashboard} />
          <Route path="/admin/dashboard" component={AdminDashboard} />
          <Route path="/admin/students" component={AdminStudents} />
          <Route path="/admin/courses" component={AdminCourses} />
          <Route path="/admin/payments" component={AdminPayments} />
          <Route path="/admin/attendance" component={AdminAttendance} />
          <Route path="/admin/reports" component={AdminReports} />
          <Route path="/admin/notifications" component={AdminNotifications} />
        </>
      )}
      
      {auth.user.role === 'student' && (
        <>
          <Route path="/" component={StudentDashboard} />
          <Route path="/student" component={StudentDashboard} />
          <Route path="/student/dashboard" component={StudentDashboard} />
          <Route path="/student/courses" component={StudentCourses} />
          <Route path="/student/payments" component={StudentPayments} />
          <Route path="/student/attendance" component={StudentAttendance} />
          <Route path="/student/progress" component={StudentProgress} />
          <Route path="/student/notifications" component={StudentNotifications} />
          <Route path="/student/profile" component={StudentProfile} />
        </>
      )}
      
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <Router />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
