import type { Express } from "express";
import { createServer, type Server } from "http";
import bcrypt from "bcrypt";
import { storage } from "./storage";
import { insertUserSchema, insertStudentSchema, insertCourseSchema, insertEnrollmentSchema, insertPaymentSchema, insertAttendanceSchema } from "@shared/schema";
import { z } from "zod";
import session from "express-session";

declare module "express-session" {
  interface SessionData {
    userId?: number;
    role?: string;
  }
}

const loginSchema = z.object({
  username: z.string().min(1),
  password: z.string().min(1),
});

export async function registerRoutes(app: Express): Promise<Server> {
  // Session configuration
  app.use(session({
    secret: process.env.SESSION_SECRET || 'your-secret-key',
    resave: false,
    saveUninitialized: false,
    cookie: {
      secure: process.env.NODE_ENV === 'production',
      maxAge: 24 * 60 * 60 * 1000 // 24 hours
    }
  }));

  // Create default admin user if not exists
  const initializeAdmin = async () => {
    try {
      const adminUser = await storage.getUserByUsername('Admin');
      if (!adminUser) {
        const hashedPassword = await bcrypt.hash('123', 10);
        await storage.createUser({
          username: 'Admin',
          password: hashedPassword,
          role: 'admin'
        });
        console.log('Default admin user created');
      }
    } catch (error) {
      console.log('Error initializing admin:', error);
    }
  };
  initializeAdmin();

  // Authentication endpoints
  app.post("/api/auth/login", async (req, res) => {
    try {
      const { username, password } = loginSchema.parse(req.body);
      
      // Try to find user by username first, then by student ID
      let user = await storage.getUserByUsername(username);
      
      // If not found by username, try to find by student ID
      if (!user) {
        const student = await storage.getStudentByStudentId(username);
        if (student) {
          user = await storage.getUser(student.userId);
        }
      }
      
      if (!user) {
        return res.status(401).json({ message: "Invalid credentials" });
      }

      const isValidPassword = await bcrypt.compare(password, user.password);
      if (!isValidPassword) {
        return res.status(401).json({ message: "Invalid credentials" });
      }

      req.session.userId = user.id;
      req.session.role = user.role;

      let studentData = null;
      if (user.role === 'student') {
        studentData = await storage.getStudentByUserId(user.id);
      }

      res.json({ 
        user: { id: user.id, username: user.username, role: user.role },
        student: studentData
      });
    } catch (error) {
      console.error('Login error:', error);
      res.status(400).json({ message: "Login failed" });
    }
  });

  app.post("/api/auth/logout", (req, res) => {
    req.session.destroy((err) => {
      if (err) {
        console.error('Logout error:', err);
        return res.status(500).json({ message: "Logout failed" });
      }
      res.clearCookie('connect.sid');
      res.json({ message: "Logged out successfully" });
    });
  });

  app.get("/api/auth/me", async (req, res) => {
    if (!req.session.userId) {
      return res.status(401).json({ message: "Not authenticated" });
    }

    try {
      const user = await storage.getUser(req.session.userId);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }

      let studentData = null;
      if (user.role === 'student') {
        studentData = await storage.getStudentByUserId(user.id);
      }

      res.json({ 
        user: { id: user.id, username: user.username, role: user.role },
        student: studentData
      });
    } catch (error) {
      res.status(500).json({ message: "Failed to get user info" });
    }
  });

  // Middleware to check authentication
  const requireAuth = (req: any, res: any, next: any) => {
    if (!req.session.userId) {
      return res.status(401).json({ message: "Authentication required" });
    }
    next();
  };

  // Middleware to check admin role
  const requireAdmin = (req: any, res: any, next: any) => {
    if (!req.session.userId || req.session.role !== 'admin') {
      return res.status(403).json({ message: "Admin access required" });
    }
    next();
  };

  // Student endpoints
  app.get("/api/students", requireAdmin, async (req, res) => {
    try {
      const students = await storage.getStudents();
      res.json(students);
    } catch (error) {
      res.status(500).json({ message: "Failed to get students" });
    }
  });

  app.get("/api/students/:id", requireAuth, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const student = await storage.getStudent(id);
      if (!student) {
        return res.status(404).json({ message: "Student not found" });
      }
      res.json(student);
    } catch (error) {
      res.status(500).json({ message: "Failed to get student" });
    }
  });

  app.post("/api/students", requireAdmin, async (req, res) => {
    try {
      const studentData = insertStudentSchema.parse(req.body);
      
      // Generate username from email
      const username = studentData.email.split('@')[0];
      const defaultPassword = 'techncode';
      
      // Create user account
      const hashedPassword = await bcrypt.hash(defaultPassword, 10);
      const user = await storage.createUser({
        username,
        password: hashedPassword,
        role: 'student'
      });

      // Create student record
      const student = await storage.createStudent({
        ...studentData,
        enrollmentDate: new Date().toISOString().split('T')[0]
      }, user.id);

      res.status(201).json({ student, credentials: { username, password: defaultPassword } });
    } catch (error) {
      console.error('Create student error:', error);
      res.status(400).json({ message: "Failed to create student" });
    }
  });

  app.put("/api/students/:id", requireAdmin, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const updateData = insertStudentSchema.partial().parse(req.body);
      const student = await storage.updateStudent(id, updateData);
      res.json(student);
    } catch (error) {
      res.status(400).json({ message: "Failed to update student" });
    }
  });

  app.delete("/api/students/:id", requireAdmin, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      await storage.deleteStudent(id);
      res.json({ message: "Student deleted successfully" });
    } catch (error) {
      res.status(500).json({ message: "Failed to delete student" });
    }
  });

  // Course endpoints
  app.get("/api/courses", requireAuth, async (req, res) => {
    try {
      const courses = await storage.getCourses();
      res.json(courses);
    } catch (error) {
      res.status(500).json({ message: "Failed to get courses" });
    }
  });

  app.get("/api/courses/:id", requireAuth, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const course = await storage.getCourse(id);
      if (!course) {
        return res.status(404).json({ message: "Course not found" });
      }
      res.json(course);
    } catch (error) {
      res.status(500).json({ message: "Failed to get course" });
    }
  });

  app.post("/api/courses", requireAdmin, async (req, res) => {
    try {
      const courseData = insertCourseSchema.parse(req.body);
      const course = await storage.createCourse(courseData);
      res.status(201).json(course);
    } catch (error) {
      res.status(400).json({ message: "Failed to create course" });
    }
  });

  app.put("/api/courses/:id", requireAdmin, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const updateData = insertCourseSchema.partial().parse(req.body);
      const course = await storage.updateCourse(id, updateData);
      res.json(course);
    } catch (error) {
      res.status(400).json({ message: "Failed to update course" });
    }
  });

  app.delete("/api/courses/:id", requireAdmin, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      await storage.deleteCourse(id);
      res.json({ message: "Course deleted successfully" });
    } catch (error) {
      res.status(500).json({ message: "Failed to delete course" });
    }
  });

  // Enrollment endpoints
  app.get("/api/enrollments", requireAuth, async (req, res) => {
    try {
      const { studentId, courseId } = req.query;
      
      if (studentId) {
        const enrollments = await storage.getEnrollmentsByStudent(parseInt(studentId as string));
        res.json(enrollments);
      } else if (courseId) {
        const enrollments = await storage.getEnrollmentsByCourse(parseInt(courseId as string));
        res.json(enrollments);
      } else {
        const enrollments = await storage.getEnrollments();
        res.json(enrollments);
      }
    } catch (error) {
      res.status(500).json({ message: "Failed to get enrollments" });
    }
  });

  app.post("/api/enrollments", requireAdmin, async (req, res) => {
    try {
      const enrollmentData = insertEnrollmentSchema.parse(req.body);
      const enrollment = await storage.createEnrollment({
        ...enrollmentData,
        enrollmentDate: new Date().toISOString().split('T')[0]
      });
      res.status(201).json(enrollment);
    } catch (error) {
      res.status(400).json({ message: "Failed to create enrollment" });
    }
  });

  // Payment endpoints
  app.get("/api/payments", requireAuth, async (req, res) => {
    try {
      const { studentId } = req.query;
      
      if (studentId) {
        const payments = await storage.getPaymentsByStudent(parseInt(studentId as string));
        res.json(payments);
      } else {
        const payments = await storage.getPayments();
        res.json(payments);
      }
    } catch (error) {
      res.status(500).json({ message: "Failed to get payments" });
    }
  });

  app.post("/api/payments", requireAdmin, async (req, res) => {
    try {
      const paymentData = insertPaymentSchema.parse(req.body);
      const payment = await storage.createPayment(paymentData);
      res.status(201).json(payment);
    } catch (error) {
      res.status(400).json({ message: "Failed to create payment" });
    }
  });

  app.put("/api/payments/:id", requireAdmin, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const updateData = insertPaymentSchema.partial().parse(req.body);
      const payment = await storage.updatePayment(id, updateData);
      res.json(payment);
    } catch (error) {
      res.status(400).json({ message: "Failed to update payment" });
    }
  });

  // Attendance endpoints
  app.get("/api/attendance", requireAuth, async (req, res) => {
    try {
      const { studentId, courseId } = req.query;
      
      if (studentId) {
        const attendance = await storage.getAttendanceByStudent(parseInt(studentId as string));
        res.json(attendance);
      } else if (courseId) {
        const attendance = await storage.getAttendanceByCourse(parseInt(courseId as string));
        res.json(attendance);
      } else {
        const attendance = await storage.getAttendance();
        res.json(attendance);
      }
    } catch (error) {
      res.status(500).json({ message: "Failed to get attendance" });
    }
  });

  app.post("/api/attendance", requireAdmin, async (req, res) => {
    try {
      const attendanceData = insertAttendanceSchema.parse(req.body);
      const attendance = await storage.createAttendance(attendanceData);
      res.status(201).json(attendance);
    } catch (error) {
      res.status(400).json({ message: "Failed to create attendance" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
