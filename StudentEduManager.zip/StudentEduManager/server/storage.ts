import { 
  users, students, courses, enrollments, payments, attendance,
  type User, type InsertUser,
  type Student, type InsertStudent, type StudentWithUser,
  type Course, type InsertCourse,
  type Enrollment, type InsertEnrollment, type EnrollmentWithDetails,
  type Payment, type InsertPayment, type PaymentWithDetails,
  type Attendance, type InsertAttendance, type AttendanceWithDetails
} from "@shared/schema";
import { db } from "./db";
import { eq, and, desc } from "drizzle-orm";

export interface IStorage {
  // User methods
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;

  // Student methods
  getStudents(): Promise<StudentWithUser[]>;
  getStudent(id: number): Promise<StudentWithUser | undefined>;
  getStudentByUserId(userId: number): Promise<StudentWithUser | undefined>;
  getStudentByStudentId(studentId: string): Promise<StudentWithUser | undefined>;
  createStudent(student: InsertStudent & { enrollmentDate?: string }, userId: number): Promise<Student>;
  updateStudent(id: number, student: Partial<InsertStudent>): Promise<Student>;
  deleteStudent(id: number): Promise<void>;

  // Course methods
  getCourses(): Promise<Course[]>;
  getCourse(id: number): Promise<Course | undefined>;
  createCourse(course: InsertCourse): Promise<Course>;
  updateCourse(id: number, course: Partial<InsertCourse>): Promise<Course>;
  deleteCourse(id: number): Promise<void>;

  // Enrollment methods
  getEnrollments(): Promise<EnrollmentWithDetails[]>;
  getEnrollmentsByStudent(studentId: number): Promise<EnrollmentWithDetails[]>;
  getEnrollmentsByCourse(courseId: number): Promise<EnrollmentWithDetails[]>;
  createEnrollment(enrollment: InsertEnrollment): Promise<Enrollment>;
  updateEnrollment(id: number, enrollment: Partial<InsertEnrollment>): Promise<Enrollment>;
  deleteEnrollment(id: number): Promise<void>;

  // Payment methods
  getPayments(): Promise<PaymentWithDetails[]>;
  getPaymentsByStudent(studentId: number): Promise<PaymentWithDetails[]>;
  createPayment(payment: InsertPayment): Promise<Payment>;
  updatePayment(id: number, payment: Partial<InsertPayment>): Promise<Payment>;

  // Attendance methods
  getAttendance(): Promise<AttendanceWithDetails[]>;
  getAttendanceByStudent(studentId: number): Promise<AttendanceWithDetails[]>;
  getAttendanceByCourse(courseId: number): Promise<AttendanceWithDetails[]>;
  createAttendance(attendance: InsertAttendance): Promise<Attendance>;
  updateAttendance(id: number, attendance: Partial<InsertAttendance>): Promise<Attendance>;
}

export class DatabaseStorage implements IStorage {
  // User methods
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user || undefined;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(insertUser)
      .returning();
    return user;
  }

  // Student methods
  async getStudents(): Promise<StudentWithUser[]> {
    const result = await db
      .select()
      .from(students)
      .leftJoin(users, eq(students.userId, users.id))
      .orderBy(desc(students.id));
    
    return result.map(row => ({
      ...row.students,
      user: row.users!
    }));
  }

  async getStudent(id: number): Promise<StudentWithUser | undefined> {
    const [result] = await db
      .select()
      .from(students)
      .leftJoin(users, eq(students.userId, users.id))
      .where(eq(students.id, id));
    
    if (!result) return undefined;
    
    return {
      ...result.students,
      user: result.users!
    };
  }

  async getStudentByUserId(userId: number): Promise<StudentWithUser | undefined> {
    const [result] = await db
      .select()
      .from(students)
      .leftJoin(users, eq(students.userId, users.id))
      .where(eq(students.userId, userId));
    
    if (!result) return undefined;
    
    return {
      ...result.students,
      user: result.users!
    };
  }

  async getStudentByStudentId(studentId: string): Promise<StudentWithUser | undefined> {
    const [result] = await db
      .select()
      .from(students)
      .leftJoin(users, eq(students.userId, users.id))
      .where(eq(students.studentId, studentId));
    
    if (!result) return undefined;
    
    return {
      ...result.students,
      user: result.users!
    };
  }

  async createStudent(insertStudent: InsertStudent & { enrollmentDate?: string }, userId: number): Promise<Student> {
    // Generate student ID
    const count = await db.select().from(students);
    const studentId = `STU${String(count.length + 1).padStart(3, '0')}`;
    
    const [student] = await db
      .insert(students)
      .values({
        ...insertStudent,
        userId,
        studentId,
        enrollmentDate: insertStudent.enrollmentDate || new Date().toISOString().split('T')[0],
      })
      .returning();
    return student;
  }

  async updateStudent(id: number, updateStudent: Partial<InsertStudent>): Promise<Student> {
    const [student] = await db
      .update(students)
      .set(updateStudent)
      .where(eq(students.id, id))
      .returning();
    return student;
  }

  async deleteStudent(id: number): Promise<void> {
    await db.delete(students).where(eq(students.id, id));
  }

  // Course methods
  async getCourses(): Promise<Course[]> {
    return await db.select().from(courses).orderBy(desc(courses.id));
  }

  async getCourse(id: number): Promise<Course | undefined> {
    const [course] = await db.select().from(courses).where(eq(courses.id, id));
    return course || undefined;
  }

  async createCourse(insertCourse: InsertCourse): Promise<Course> {
    const [course] = await db
      .insert(courses)
      .values(insertCourse)
      .returning();
    return course;
  }

  async updateCourse(id: number, updateCourse: Partial<InsertCourse>): Promise<Course> {
    const [course] = await db
      .update(courses)
      .set(updateCourse)
      .where(eq(courses.id, id))
      .returning();
    return course;
  }

  async deleteCourse(id: number): Promise<void> {
    await db.delete(courses).where(eq(courses.id, id));
  }

  // Enrollment methods
  async getEnrollments(): Promise<EnrollmentWithDetails[]> {
    const result = await db
      .select()
      .from(enrollments)
      .leftJoin(students, eq(enrollments.studentId, students.id))
      .leftJoin(courses, eq(enrollments.courseId, courses.id))
      .orderBy(desc(enrollments.id));
    
    return result.map(row => ({
      ...row.enrollments,
      student: row.students!,
      course: row.courses!
    }));
  }

  async getEnrollmentsByStudent(studentId: number): Promise<EnrollmentWithDetails[]> {
    const result = await db
      .select()
      .from(enrollments)
      .leftJoin(students, eq(enrollments.studentId, students.id))
      .leftJoin(courses, eq(enrollments.courseId, courses.id))
      .where(eq(enrollments.studentId, studentId))
      .orderBy(desc(enrollments.id));
    
    return result.map(row => ({
      ...row.enrollments,
      student: row.students!,
      course: row.courses!
    }));
  }

  async getEnrollmentsByCourse(courseId: number): Promise<EnrollmentWithDetails[]> {
    const result = await db
      .select()
      .from(enrollments)
      .leftJoin(students, eq(enrollments.studentId, students.id))
      .leftJoin(courses, eq(enrollments.courseId, courses.id))
      .where(eq(enrollments.courseId, courseId))
      .orderBy(desc(enrollments.id));
    
    return result.map(row => ({
      ...row.enrollments,
      student: row.students!,
      course: row.courses!
    }));
  }

  async createEnrollment(insertEnrollment: InsertEnrollment): Promise<Enrollment> {
    const [enrollment] = await db
      .insert(enrollments)
      .values(insertEnrollment)
      .returning();
    return enrollment;
  }

  async updateEnrollment(id: number, updateEnrollment: Partial<InsertEnrollment>): Promise<Enrollment> {
    const [enrollment] = await db
      .update(enrollments)
      .set(updateEnrollment)
      .where(eq(enrollments.id, id))
      .returning();
    return enrollment;
  }

  async deleteEnrollment(id: number): Promise<void> {
    await db.delete(enrollments).where(eq(enrollments.id, id));
  }

  // Payment methods
  async getPayments(): Promise<PaymentWithDetails[]> {
    const result = await db
      .select()
      .from(payments)
      .leftJoin(students, eq(payments.studentId, students.id))
      .leftJoin(courses, eq(payments.courseId, courses.id))
      .orderBy(desc(payments.id));
    
    return result.map(row => ({
      ...row.payments,
      student: row.students!,
      course: row.courses!
    }));
  }

  async getPaymentsByStudent(studentId: number): Promise<PaymentWithDetails[]> {
    const result = await db
      .select()
      .from(payments)
      .leftJoin(students, eq(payments.studentId, students.id))
      .leftJoin(courses, eq(payments.courseId, courses.id))
      .where(eq(payments.studentId, studentId))
      .orderBy(desc(payments.id));
    
    return result.map(row => ({
      ...row.payments,
      student: row.students!,
      course: row.courses!
    }));
  }

  async createPayment(insertPayment: InsertPayment): Promise<Payment> {
    const [payment] = await db
      .insert(payments)
      .values(insertPayment)
      .returning();
    return payment;
  }

  async updatePayment(id: number, updatePayment: Partial<InsertPayment>): Promise<Payment> {
    const [payment] = await db
      .update(payments)
      .set(updatePayment)
      .where(eq(payments.id, id))
      .returning();
    return payment;
  }

  // Attendance methods
  async getAttendance(): Promise<AttendanceWithDetails[]> {
    const result = await db
      .select()
      .from(attendance)
      .leftJoin(students, eq(attendance.studentId, students.id))
      .leftJoin(courses, eq(attendance.courseId, courses.id))
      .orderBy(desc(attendance.date));
    
    return result.map(row => ({
      ...row.attendance,
      student: row.students!,
      course: row.courses!
    }));
  }

  async getAttendanceByStudent(studentId: number): Promise<AttendanceWithDetails[]> {
    const result = await db
      .select()
      .from(attendance)
      .leftJoin(students, eq(attendance.studentId, students.id))
      .leftJoin(courses, eq(attendance.courseId, courses.id))
      .where(eq(attendance.studentId, studentId))
      .orderBy(desc(attendance.date));
    
    return result.map(row => ({
      ...row.attendance,
      student: row.students!,
      course: row.courses!
    }));
  }

  async getAttendanceByCourse(courseId: number): Promise<AttendanceWithDetails[]> {
    const result = await db
      .select()
      .from(attendance)
      .leftJoin(students, eq(attendance.studentId, students.id))
      .leftJoin(courses, eq(attendance.courseId, courses.id))
      .where(eq(attendance.courseId, courseId))
      .orderBy(desc(attendance.date));
    
    return result.map(row => ({
      ...row.attendance,
      student: row.students!,
      course: row.courses!
    }));
  }

  async createAttendance(insertAttendance: InsertAttendance): Promise<Attendance> {
    const [attendanceRecord] = await db
      .insert(attendance)
      .values(insertAttendance)
      .returning();
    return attendanceRecord;
  }

  async updateAttendance(id: number, updateAttendance: Partial<InsertAttendance>): Promise<Attendance> {
    const [attendanceRecord] = await db
      .update(attendance)
      .set(updateAttendance)
      .where(eq(attendance.id, id))
      .returning();
    return attendanceRecord;
  }
}

export const storage = new DatabaseStorage();
