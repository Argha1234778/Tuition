import { z } from "zod";

export const insertNotificationSchema = z.object({
  userId: z.number(),
  title: z.string().min(1).max(255),
  message: z.string().min(1).max(1000),
  type: z.enum(['info', 'success', 'warning', 'error', 'reminder']),
  category: z.enum(['payment', 'attendance', 'course', 'grade', 'system', 'announcement']),
  priority: z.enum(['low', 'medium', 'high', 'urgent']),
  isRead: z.boolean().default(false),
  actionUrl: z.string().optional(),
  actionLabel: z.string().optional(),
  scheduledFor: z.string().optional(), // ISO date string for scheduled notifications
  expiresAt: z.string().optional(), // ISO date string for expiring notifications
});

export const notificationSchema = insertNotificationSchema.extend({
  id: z.number(),
  createdAt: z.string(),
  readAt: z.string().optional(),
});

export const notificationPreferencesSchema = z.object({
  userId: z.number(),
  emailNotifications: z.boolean().default(true),
  pushNotifications: z.boolean().default(true),
  smsNotifications: z.boolean().default(false),
  paymentReminders: z.boolean().default(true),
  attendanceAlerts: z.boolean().default(true),
  gradeUpdates: z.boolean().default(true),
  courseAnnouncements: z.boolean().default(true),
  systemUpdates: z.boolean().default(true),
  quietHoursStart: z.string().default('22:00'),
  quietHoursEnd: z.string().default('08:00'),
  weekendNotifications: z.boolean().default(false),
});

export type Notification = z.infer<typeof notificationSchema>;
export type InsertNotification = z.infer<typeof insertNotificationSchema>;
export type NotificationPreferences = z.infer<typeof notificationPreferencesSchema>;

export interface NotificationWithUser extends Notification {
  user: {
    id: number;
    username: string;
    role: 'admin' | 'student';
  };
}