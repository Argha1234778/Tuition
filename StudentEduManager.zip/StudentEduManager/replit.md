# TechNCode - Student Management System

## Overview

TechNCode is a comprehensive full-stack student management system built with modern web technologies. It serves as a platform for educational institutions to manage students, courses, payments, and attendance tracking. The system provides separate interfaces for administrators and students, with role-based access control and comprehensive data management capabilities.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

The application follows a full-stack TypeScript architecture with a clear separation between client, server, and shared components. It uses a monorepo structure with the following key architectural decisions:

### Frontend Architecture
- **Framework**: React 18 with TypeScript for type safety
- **Build Tool**: Vite for fast development and optimized builds
- **UI Library**: Radix UI components with shadcn/ui styling
- **Styling**: Tailwind CSS with CSS custom properties for theming
- **State Management**: TanStack Query (React Query) for server state
- **Routing**: Wouter for lightweight client-side routing
- **Forms**: React Hook Form with Zod validation

### Backend Architecture
- **Runtime**: Node.js with Express.js framework
- **Language**: TypeScript with ESM modules
- **Database ORM**: Drizzle ORM for type-safe database operations
- **Database**: PostgreSQL (configured for Neon serverless)
- **Authentication**: Express sessions with bcrypt password hashing
- **API Design**: RESTful API with JSON responses

## Key Components

### Authentication System
- Session-based authentication using express-session
- Role-based access control (admin/student roles)
- Password hashing with bcrypt
- Default admin account creation (username: Admin, password: 123)
- Student authentication using Student ID or username with default password "techncode"
- Copyright attribution to "Argha Sir"

### Database Schema
The system uses a relational database with the following core entities:
- **Users**: Authentication and role management
- **Students**: Student profile information linked to users
- **Courses**: Course catalog with pricing and capacity
- **Enrollments**: Student-course relationships with progress tracking
- **Payments**: Financial transactions and payment status
- **Attendance**: Daily attendance records per course

### User Interface
- **Admin Interface**: Full CRUD operations for all entities, dashboard with analytics
- **Student Interface**: Personal dashboard, course enrollment, payment history, attendance view
- **Responsive Design**: Mobile-first approach with Tailwind CSS
- **Component Library**: Consistent UI using shadcn/ui components

### Data Management
- **Type Safety**: Shared TypeScript schemas between frontend and backend
- **Validation**: Zod schemas for runtime type checking
- **Query Management**: TanStack Query for caching and synchronization
- **Form Handling**: React Hook Form with resolver-based validation

## Data Flow

1. **Authentication Flow**: Users log in through a centralized login page, sessions are managed server-side
2. **Route Protection**: Frontend checks authentication status and redirects based on user role
3. **API Communication**: Frontend makes HTTP requests to RESTful endpoints
4. **Database Operations**: Server uses Drizzle ORM to interact with PostgreSQL
5. **Real-time Updates**: Query invalidation ensures UI stays synchronized with server state

## External Dependencies

### Database
- **Neon Database**: Serverless PostgreSQL with connection pooling
- **Drizzle Kit**: Database migrations and schema management

### UI and Styling
- **Radix UI**: Headless components for accessibility
- **Tailwind CSS**: Utility-first styling framework
- **Lucide React**: Icon library for consistent iconography

### Development Tools
- **Vite**: Development server and build tool
- **TypeScript**: Static type checking
- **ESBuild**: Fast JavaScript bundling for production

## Deployment Strategy

The application is configured for modern deployment platforms:

### Development
- Vite dev server for frontend with HMR support
- tsx for running TypeScript server code directly
- Environment-based configuration for database connections

### Production Build
- Vite builds optimized client bundle to `dist/public`
- ESBuild bundles server code to `dist/index.js`
- Static file serving integrated with Express server

### Database Management
- Drizzle migrations stored in `./migrations` directory
- Database push command for schema deployment
- Environment variable configuration for database URL

## Recent Changes

### Smart Notification System Implementation (January 20, 2025)
- **Notification Center**: Real-time notification component with badge indicators and popover interface
- **Admin Notifications**: Complete notification management system with templates, sending, history, and analytics
- **Student Notifications**: Personalized notification feed with filtering, categorization, and preferences
- **Notification Preferences**: Comprehensive settings for delivery methods, types, quiet hours, and smart features
- **Study Materials**: Google Classroom-style document management system integrated with courses
- **Report Downloads**: Complete CSV export functionality for all report types
- **Enhanced UI**: Improved notification icons, priority indicators, and user experience

### Key Architecture Benefits
1. **Type Safety**: End-to-end TypeScript ensures consistency
2. **Developer Experience**: Fast builds, hot reloading, and good tooling
3. **Scalability**: Modular structure supports feature growth
4. **Maintainability**: Clear separation of concerns and shared schemas
5. **Performance**: Optimized builds and efficient query management
6. **Smart Features**: AI-powered notification timing and personalized alerts (coming soon)